# V20.2 GUI Group Photo Downloads

V20.2 is a small interface update on top of V20.1.

## Photo Intake
Open an intake session. Under **Detected / defined sets**, every set now has a prominent **⬇ Download ZIP** button. It downloads every original photo currently assigned to that effective set and excludes the NEW SET marker image. Manual grouping overrides are honored.

## Logical Groups
Open **Logical Groups**. The **Photos** column now contains a prominent **⬇ Download ZIP** button for each logical group. It downloads catalog photos belonging to the group's member item IDs.

## API
No API behavior changed. V20.2 uses the V20.1 ZIP endpoints:

- `GET /api/v1/intake/sessions/{session_id}/groups/{group_id}/photos.zip`
- `GET /api/v1/logical-groups/{group_id}/photos.zip`

The management GUI uses the corresponding management routes and does not require the user to type an API URL or Bearer token.
