# Lionel Train Catalog — V8

A photo-first web catalog for Lionel trains and accessories. It is designed for fast collection work: photograph an item on a phone, save it immediately, then identify and group it later on the phone or a computer.

V8 keeps the permanent-data, PWA, multi-group, and Android-wrapper architecture and adds reusable custom status labels. Items can have multiple statuses, statuses can be created during capture or editing, the catalog can filter/search by status, and unused statuses can be deleted.

## Normal workflow

1. Open the hosted catalog at `https://trains.signallosscalculator.com`.
2. On Android, use the installed wrapper/PWA or a normal browser.
3. Open **Take photos** and grant camera permission.
4. Select any groups and statuses that apply, or create new ones directly on the capture screen.
5. Photograph one train or piece and save the batch. It becomes an unlabeled entry with those groups and statuses already attached.
6. Continue photographing items, then use **Needs details** to add names and notes later.
7. Reopen any entry to add more photographs; its numbering continues automatically.
8. Empty groups can be deleted from **Manage groups** on the catalog page. Groups that still contain items are protected from deletion until those items are moved or ungrouped.

Photo names use the catalog entry ID so duplicate model names do not collide. An unlabeled entry might begin as:

```text
Unlabeled 12_001_ID12.jpg
Unlabeled 12_002_ID12.jpg
```

After the item is named `Lionel 2026 Locomotive`, those same files are renamed to:

```text
Lionel 2026 Locomotive_001_ID12.jpg
Lionel 2026 Locomotive_002_ID12.jpg
```

## Install the catalog as an Android app

The catalog can now be installed from Chrome while using the Tailscale HTTPS address.

1. Start the Windows catalog server.
2. Connect Tailscale on the Android phone.
3. Open the catalog using its `https://...ts.net` address in Chrome.
4. Open **Backup & App**.
5. Tap **Install Lionel Catalog** when the button appears.
6. If Chrome does not show the button, open Chrome's menu and choose **Install app** or **Add to Home screen**.

After installation, the catalog has its own home-screen icon, opens in a standalone app window without the normal browser address bar, and starts directly on the photo-capture page.

The PWA is still a client for the Windows server. The PC server must be running and Tailscale must be connected on the phone. If the server cannot be reached, the installed app shows a simple offline message instead of an old cached catalog page.

### Bluetooth shutter note

The V4 learnable Bluetooth-shutter feature remains available for remotes that send ordinary keyboard events to the browser. The SmallRig remote tested in this project maps its shutter to Android **Volume Up**. Android handles that key before Chrome/PWA JavaScript receives it, so installing the PWA does not by itself enable that physical shutter.

A future thin Android wrapper can intercept `KEYCODE_VOLUME_UP` and forward it to the existing camera JavaScript without changing the Windows server, permanent catalog data, or normal web interface.

## Windows installation

Install Python 3.10 or newer. From the application folder:

```powershell
py -m pip install -r requirements.txt
```

The included Windows launcher is the recommended start method:

```text
Start_Lionel_Catalog.bat
```

It uses this permanent Windows data location:

```text
%USERPROFILE%\LionelCatalogData
```

The launcher currently contains the Tailscale HTTPS hostname configured for this installation. If the PC hostname or tailnet changes, edit `CATALOG_URL` near the top of the batch file.

To start Flask manually:

```powershell
set CATALOG_DATA=%USERPROFILE%\LionelCatalogData
py app.py
```

Then browse locally to `http://localhost:5000`. The live phone camera requires a secure context, so the phone should use the Tailscale `https://...ts.net` URL rather than an HTTP LAN or numeric Tailscale IP address.

## Permanent data and seamless upgrades

The application code and collection data are intentionally separated. On Windows the collection lives in:

```text
%USERPROFILE%\LionelCatalogData
```

It contains:

```text
catalog.sqlite3
photos\
thumbs\
```

When installing V5 over V4, **do not move or replace this folder**. Extract the new application somewhere convenient and run its launcher. It points to the same permanent data directory, so the existing database and photographs appear automatically.

### Importing an older V1–V3 catalog

If the permanent folder does not yet contain `catalog.sqlite3`, the app checks standard old-version locations and copies an existing catalog into the permanent folder. The old data is not deleted.

For a V3 installation in a nonstandard location, edit and run:

```text
Import_V3_Data.bat
```

before first launch. The script refuses to overwrite an existing permanent database.

## Backup

Open **Backup & App** and select **Download complete backup**. The generated ZIP includes:

- `catalog.sqlite3`
- all catalog photographs
- generated thumbnails

Keep occasional backups on another drive or computer. The permanent data folder makes upgrades safe and easy, but it does not protect against disk failure or accidental deletion.

## Camera and image handling

The in-browser camera uses `getUserMedia`, which requires HTTPS on a phone. Captured frames are sent to the server as JPEG images. Uploaded images are auto-rotated using EXIF information, converted to JPEG, and reduced to a maximum dimension of 3200 pixels. Thumbnails are generated for fast catalog browsing.

The original pixel-perfect upload is not retained after normalization. Keep original photos separately if that matters for archival purposes.

The batch upload limit is 120 MB.

## PWA files added in V5

V5 adds:

```text
static/manifest.webmanifest
static/sw.js
static/pwa.js
static/offline.html
static/icons/
```

The service worker intentionally does **not** cache database-generated catalog pages or train photographs for offline use. It caches only the app shell/static assets and an offline notice. This avoids displaying stale collection data when the Windows server is unavailable.


## V6 server deployment

The Android wrapper still opens `/capture` and the physical Volume Up shutter continues to target the existing `#takePhoto` button, so no Android rebuild is required for V6. Deploy the updated web files, install requirements if needed, and restart the Gunicorn systemd service.


## V7 multi-group support

V7 changes groups into many-to-many tags. Each catalog item can belong to any number of groups. Existing V6 single-group assignments are migrated automatically the first time V7 starts; no manual database conversion is required. Group filtering matches items that contain the selected group, and a group can only be deleted when it is no longer assigned to any items.

## V9 listing deletion

An item detail page now includes **Delete listing**. This permanently removes the catalog item, all group/status assignments for that item, all photo database records, and the associated full-size and thumbnail image files. A confirmation prompt is required before deletion.


## V10 navigation, favicon, and Android download

- The redundant Catalog navigation link was removed; tapping the train logo/title returns to the catalog.
- Browser favicon assets now use the same train artwork as the PWA/app icon.
- Backup & App includes a stable GitHub Releases download link for the Android wrapper. Publish the signed APK as a GitHub Release asset named `LionelCatalog.apk`.


## Public view-only catalog (V14)

The shareable catalog is available at `/` (also `/view`). The management catalog is intentionally unlinked from the public side and lives at `/manage`. Management pages link to **View public catalog**. This is unlisted, not authenticated; add login protection if management access must be secured.


## API (V17)

The catalog includes a token-protected API. The public catalog remains readable without a token; API write/read endpoints require `LIONEL_API_TOKEN`. V17 adds authenticated read-only photograph retrieval for visual-inspection clients.

Endpoints:

```text
POST /api/v1/items
POST /api/v1/items/<id>/photos
GET  /api/v1/items
GET  /api/v1/items/<id>
GET  /api/v1/items/<id>/photos
GET  /api/v1/items/<id>/photos/<number>
GET  /api/v1/items/<id>/photos.zip
GET  /api/v1/groups
GET  /api/v1/statuses
```

`POST /api/v1/items` accepts `multipart/form-data`:

- `name` (required)
- `description`
- `groups` / `group` (repeat the field or use comma-separated values)
- `statuses` / `status` (repeat the field or use comma-separated values)
- `photos` / `files` (repeat for multiple image files)
- `archive` (optional ZIP containing a folder of images)

Group and status matching is case-insensitive. Any supplied group/status that does not already exist is created automatically.

Authentication uses either:

```text
Authorization: Bearer YOUR_TOKEN
```

or `X-API-Key: YOUR_TOKEN`.

Example:

```bash
curl -X POST https://trains.signallosscalculator.com/api/v1/items \
  -H "Authorization: Bearer $LIONEL_TOKEN" \
  -F "name=Lionel 736 Berkshire" \
  -F "description=Postwar locomotive" \
  -F "groups=Locomotives,Postwar,Steam" \
  -F "statuses=Working,Cataloged" \
  -F "photos=@front.jpg" \
  -F "photos=@side.jpg"
```

To configure the production systemd service, store the token outside GitHub, for example in `/etc/lionel-catalog.env`:

```text
LIONEL_API_TOKEN=replace-with-a-long-random-token
```

Protect the file with `chmod 600`, add `EnvironmentFile=/etc/lionel-catalog.env` to the `[Service]` section of `lionel-catalog.service`, then run `systemctl daemon-reload` and restart the service.

## API read endpoints

Authenticated API clients can now list and search the catalog with `GET /api/v1/items`, filter by `group`, `status`, or `search`, and discover existing labels with `GET /api/v1/groups` and `GET /api/v1/statuses`. See `API_SETUP.md` for examples.



### Authenticated photo retrieval (V17)

`GET /api/v1/items/<id>/photos` returns photo metadata and authenticated download URLs. `GET /api/v1/items/<id>/photos/<number>` returns the stored JPEG image itself. `GET /api/v1/items/<id>/photos.zip` returns all available photographs for that item as a ZIP. These routes are read-only and require the existing API Bearer token; they do not expose public image URLs.

## V18 - photo intake sessions

V18 adds a staging area for the photo-first workflow requested for larger cataloging sessions. The new **Photo Intake** page lets a user create a persistent session and import batches from Android Gallery or a computer without first creating inventory items.

Key behavior:

- Original uploaded files are preserved unchanged in `intake_originals/`; separate JPEG thumbnails are created in `intake_thumbs/`.
- SHA-256 hashes detect exact repeat imports and skip duplicate originals.
- EXIF capture time is preserved when available, along with the original filename, byte size, import time, and an optional source reference.
- Sessions are resumable: additional photo batches can be imported later into the same session.
- A photo can be marked as the reusable **NEW SET** marker. The marker is excluded from the set itself, and subsequent photos are grouped until the next marker.
- Filename-based `NEW SET` recognition is included as a convenience. Actual visual AI recognition of the card is intentionally deferred to the analysis stage rather than pretending to provide image recognition in the Flask server.
- Any photo's automatic group can be manually overridden or manually left unassigned.
- Set/group records receive persistent UUIDs.
- Existing catalog records receive a `physical_uuid` field so API clients are not forced to treat the mutable display name or numeric database ID as the only identity.
- Intake sessions are not automatically committed into the master catalog. This preserves the human-review boundary requested for the later AI workflow.

Authenticated read-only API endpoints for intake review:

- `GET /api/v1/intake/sessions`
- `GET /api/v1/intake/sessions/<id>`
- `GET /api/v1/intake/sessions/<id>/photos/<photo_id>` (returns the unchanged original image)

The complete backup ZIP now includes both intake originals and intake thumbnails in addition to the catalog database and normal catalog images.

## V18.1 scoped API credentials

V18.1 keeps `LIONEL_API_TOKEN` as a backwards-compatible administrative credential and adds `LIONEL_CHATGPT_API_TOKEN` for a dedicated read-only ChatGPT/integration credential. Read-only clients receive `read:inventory`, `read:photos`, and `read:intake`; inventory POST routes require `write:inventory` and return HTTP 403 for read-only tokens.

Use `GET /api/v1/auth/me` to verify which named credential is active and which scopes it has. See `CHATGPT_READONLY_SETUP.md` and `openapi_chatgpt_readonly.yaml`.

## V19 - Matching & Reconciliation Preview

V19 adds a review-only bridge between Photo Intake and later master-inventory reconciliation.

- Import the approved-format filename mapping workbook (`.xlsx`) or a normalized `.csv`.
- The import is idempotent by SHA-256: re-importing the exact same file reuses the existing preview.
- Exact original filename is tried first. Case-insensitive filename comparison is only a secondary aid.
- Rows are classified as `ready`, `missing`, `ambiguous`, `duplicate`, `conflict`, or `review`.
- Bulk approval only approves clean `ready` rows. Approving a mapping row does **not** overwrite or attach anything to the master catalog; it only records the reviewed proposal.
- Individual approvals/rejections can be undone. A rollback resets all decisions in an import while retaining the audit history.
- `/logical-groups` introduces a separate proposed logical set/group model from the physical R-box. V19 never invents suffixes automatically.
- `/audit` shows API access and management decisions without storing API secrets.
- Read-only bulk exports are available for inventory, intake, matching previews, and audit history.

Management URLs:

- `/matching`
- `/logical-groups`
- `/audit`

Read-only API additions:

- `GET /api/v1/matching/imports`
- `GET /api/v1/matching/imports/{id}`
- `GET /api/v1/logical-groups`
- `GET /api/v1/export/inventory.json` or `.csv`
- `GET /api/v1/export/intake.json` or `.csv`
- `GET /api/v1/export/matching/{id}.json` or `.csv`
- `GET /api/v1/export/audit.json` or `.csv`

The dedicated ChatGPT token now includes `read:export`. Default API rate limit is 120 requests/minute per process/client and can be changed with `LIONEL_API_RATE_LIMIT`.


## V20 - AI Review Engine

V20 adds proposal-only visual analysis for Photo Intake groups and existing catalog items. See `V20_AI_REVIEW_SETUP.md`. The AI review layer stores identification, component, and visual-condition proposals plus confidence/evidence/uncertainty and section-level review decisions. It does not modify master inventory records.


## V20.2 - GUI group photo downloads
V20.2 makes the V20.1 group ZIP endpoints directly accessible from the management interface. Intake-session sets show a prominent `Download ZIP` button beside the set name, and Logical Groups show the same control in the Photos column. The download contains the same original/group member photos returned by the existing authenticated ZIP routes.
