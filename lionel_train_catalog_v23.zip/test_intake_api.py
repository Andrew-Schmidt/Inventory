import os, tempfile, sys, json, uuid
from pathlib import Path
root=tempfile.TemporaryDirectory()
os.environ['CATALOG_DATA']=root.name
os.environ['LIONEL_CHATGPT_API_TOKEN']='test-chatgpt-token'
os.environ['LIONEL_API_TOKEN']='test-admin-token'
sys.path.insert(0,str(Path(__file__).parent/'lionel_catalog'))
import app as m
from datetime import datetime,timezone
now=m._now_iso()
with m.connect() as db:
    for sid in (1,2):db.execute('INSERT INTO intake_sessions(id,session_uuid,name,created_at,updated_at) VALUES (?,?,?,?,?)',(sid,str(uuid.uuid4()),f'Session {sid}',now,now))
    for gid,sid in [(1,1),(2,1),(3,2)]:db.execute('INSERT INTO intake_groups(id,session_id,group_uuid,label,sequence,created_at) VALUES (?,?,?,?,?,?)',(gid,sid,str(uuid.uuid4()),'Set',gid,now))
    for pid,sid,gid in [(4,1,1),(5,1,1),(6,2,3)]:db.execute('''INSERT INTO intake_photos(id,session_id,sequence,original_name,stored_name,sha256,imported_at,auto_group_id) VALUES (?,?,?,?,?,?,?,?)''',(pid,sid,pid,f'{pid}.jpg',f'{pid}.jpg',f'hash{pid}',now,gid))
    db.commit()
c=m.app.test_client()
headers={'Authorization':'Bearer test-chatgpt-token','Idempotency-Key':'example-1'}
def post(path,payload,headers=headers):return c.post('/api/v1/intake/sessions/1/'+path,json=payload,headers=headers)
plan={'expected_revision':0,'groups':[{'key':'g','label':'One','sequence':1}],'assignments':[{'group':'g','photo_ids':[4,5]}],'delete_empty_group_ids':[1]}
assert c.get('/api/v1/auth/me',headers=headers).json['scopes']==sorted(['read:inventory','read:photos','read:intake','read:export','write:intake_groups','delete:intake_groups'])
assert c.post('/api/v1/items',headers=headers,json={'name':'x'}).status_code==403
before=c.get('/api/v1/intake/sessions/1',headers=headers).json
BASE_REV=before['revision']
r=post('regroup/preview',plan); assert r.status_code==200, (r.status_code,r.json)
assert c.get('/api/v1/intake/sessions/1',headers=headers).json==before
r=post('regroup/apply',plan); assert r.status_code==200,(r.status_code,r.json)
first=r.json
assert first['revision']>BASE_REV and first['photo_count']==2
assert post('regroup/apply',plan).json==first
with m.connect() as db:
    assert db.execute('SELECT COUNT(*) c FROM intake_groups WHERE session_id=1').fetchone()['c']==2
assert post('regroup/apply',dict(plan,expected_revision=0),dict(headers,**{'Idempotency-Key':'fresh'})).status_code==409
assert post('regroup/preview',{'expected_revision':first['revision'],'assignments':[{'group':3,'photo_ids':[4]}]}).status_code==422
assert post('regroup/preview',{'expected_revision':first['revision'],'assignments':[{'group':2,'photo_ids':[4,4]}]}).status_code==422
assert post('regroup/preview',{'expected_revision':first['revision'],'delete_empty_group_ids':[first['created_group_ids']['g']]}).status_code==422
assert post('regroup/preview',{'expected_revision':first['revision'],'assignments':[{'group':2,'photo_ids':[4,6]}]}).status_code==422
assert c.delete('/api/v1/intake/sessions/1/groups/3',headers=headers,json={'expected_revision':first['revision']}).status_code==422
assert c.delete('/api/v1/intake/sessions/1/groups/1',headers=headers,json={'expected_revision':first['revision']}).status_code==422
assert c.delete('/api/v1/intake/sessions/1',headers=headers).status_code in (404,405)
assert c.delete('/api/v1/intake/sessions/1/photos/4',headers=headers).status_code in (404,405)
print('PASS disposable DB: scopes, authorization, preview, apply, retry, revision, cross-session, duplicates, empty deletion, protected resources')
