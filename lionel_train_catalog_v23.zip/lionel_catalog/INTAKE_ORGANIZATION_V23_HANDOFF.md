# V23 Intake Organization API — deployment handoff

**Status:** source patch prepared, Python syntax checked. Integration tests are supplied but **not executed** in this environment: Flask was unavailable. **Not deployed; production credentials and session 3 were not changed.** Do not tell Dad's ChatGPT these operations are live until you deploy and verify.

## Scope boundaries

The environment `LIONEL_CHATGPT_API_TOKEN` keeps its existing four scopes (`read:inventory`, `read:photos`, `read:intake`, `read:export`) and gains only `write:intake_groups` and `delete:intake_groups`. `write:inventory` is not granted. The separate admin token stays backward-compatible. If Dad's credential is supplied via `/etc/lionel-catalog-api-tokens.json` rather than the environment variable, add the two new scope strings to its **existing** entry (do not regenerate the token). In either case, verify `/auth/me` after restarting.

All routes below begin with `https://trains.signallosscalculator.com/api/v1`. Requests require bearer auth; mutations require `Idempotency-Key` (unique per logical request) and `expected_revision`, obtained from GET session. Never place token in docs, logs or URLs.

| Method | Path | Purpose |
|--|--|--|
| GET | `/intake/sessions/{session_id}/groups` | Group IDs, labels, orders, photo IDs, counts and revision |
| POST | `/intake/sessions/{session_id}/groups` | Create group (`label`, `sequence`, `expected_revision`) |
| PATCH | `/intake/sessions/{session_id}/groups/{group_id}` | Rename/reorder (`label`, `sequence`, `expected_revision`) |
| POST | `/intake/sessions/{session_id}/groups/{group_id}/photos` | Assign (`photo_ids`, `expected_revision`) |
| PATCH | `/intake/sessions/{session_id}/markers` | Correct (`markers`, `expected_revision`) |
| DELETE | `/intake/sessions/{session_id}/groups/{group_id}` | Delete empty container (`expected_revision`) |
| POST | `/intake/sessions/{session_id}/regroup/preview` | Validate/preview complete plan, no idempotency header required |
| POST | `/intake/sessions/{session_id}/regroup/apply` | Apply atomic plan with idempotency key |
| GET | `/intake/sessions/{session_id}` | Complete session, groups and photos with revision |

## Example: preview then apply (disposable session only)

Use the same JSON request body for both calls. `key` is a request-local alias, not a catalog group ID. The example ID `9999` is illustrative; replace with a **disposable** existing session, its current `revision`, and its own photo IDs. This example is intentionally not the approved Lionel session-3 plan.

```json
{
  "expected_revision": 0,
  "groups": [{"key": "sample", "label": "Example sample group", "sequence": 1}],
  "assignments": [{"group": "sample", "photo_ids": [10001, 10002]}],
  "markers": [{"photo_id": 10001, "is_marker": false}],
  "delete_empty_group_ids": []
}
```

```bash
BASE='https://trains.signallosscalculator.com/api/v1'
# Set TOKEN from your secret store; never paste its literal value into your shell history.
curl -sS -X POST "$BASE/intake/sessions/9999/regroup/preview" \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  --data-binary @plan.json
curl -sS -X POST "$BASE/intake/sessions/9999/regroup/apply" \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: disposable-test-plan-1' --data-binary @plan.json
```

Example preview response shape (IDs/counts illustrative):

```json
{"success":true,"dry_run":true,"valid":true,"revision":0,"affected_group_ids":[1,-1],"photo_counts":{"1":0,"-1":2},"groups":[{"id":1,"label":"Old","sequence":1,"photo_count":0},{"id":-1,"label":"Example sample group","sequence":1,"photo_count":2}],"changes":[{"action":"create_group","key":"sample","label":"Example sample group","sequence":1},{"action":"assign_photo","photo_id":10001,"old_group_id":1,"new_group_id":-1}]}
```

Example apply response shape:

```json
{"success":true,"dry_run":false,"revision":1,"created_group_ids":{"sample":14},"photo_count":2,"groups":[{"id":14,"group_uuid":"...","label":"Example sample group","sequence":1,"photo_count":2,"photo_ids":[10001,10002],"photos_zip_url":"..."}]}
```

Preview uses temporary negative group IDs. Apply returns persistent positive IDs. An apply runs all validation before mutation, then writes within a SQLite `BEGIN IMMEDIATE` transaction; exceptions roll back via the connection context manager. The audit record stores old/new group IDs and marker values for every photo in the session, plus the operation details. Exactly matching retries with the same idempotency key return the original response **before** checking stale revision. Reusing the same key for a different plan returns 409. Different-key requests with outdated `expected_revision` return 409 plus `current_revision`.

Errors: 400 malformed body/missing key/revision; 401 unauthenticated; 403 scope forbidden; 404 missing session; 409 stale revision/key collision/DB conflict; 422 invalid references, duplicates, nonempty groups, active-marker group removal; 429 rate limited. Group IDs are intake-only, never catalog groups. Deleting group records cannot delete images, inventory, original filenames, filesystem folders or other sessions.

**Concurrency caveat:** This V23 revision increments on these API write endpoints. Existing manual web UI grouping operations do not necessarily increment it; coordinate against simultaneous UI edits before production use. Review live marker recomputation before applying plans that remove auto-detected marker-linked containers. The plan API rejects deletion of an active marker group.

## Deployment checklist (operator-controlled, not performed)

1. Back up database and intake originals. Copy V23 code via normal release process, keeping production DB/storage and `/etc/lionel-catalog.env` untouched. Do not replace the server database with an archive file.
2. On server, use current update/deploy routine, restart `lionel-catalog`, inspect service logs, and confirm HTTPS read endpoints. Do not perform write tests in collection session 3.
3. Run `python -m pip install -r requirements.txt` in isolated venv and `python test_intake_api.py` against disposable data. Confirm reported PASS before granting access. Also test UI/manual marker behavior.
4. `GET /api/v1/auth/me` with existing ChatGPT credential should show six scopes; verify inventory, intake and photo reads, and blocked inventory writes.
5. Import `openapi_chatgpt_intake_organization_v23.yaml` into Dad's ChatGPT plugin after successful release. Preview and user approval happen separately later; no grouping plan has been applied.
