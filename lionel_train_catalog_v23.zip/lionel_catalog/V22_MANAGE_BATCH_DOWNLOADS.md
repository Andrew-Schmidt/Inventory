# V22 — Group-view download update

V22 now places the ZIP download where it is needed: while viewing a catalog group on the Manage side.

## Workflow

1. Open `/manage`.
2. In **Manage groups**, click **View** beside a populated group, or select the group from the Group filter.
3. Above the item cards, a panel shows **Viewing group: <name>**.
4. Click **Download all files in this group** to download every catalog photo belonging to every item in that group.

The ZIP uses the existing `/manage/photos.zip?group=<id>` route and is therefore limited to the selected group.

This replaces the separate Batch photo downloads panel from the earlier V22 package to make the action contextual to the group being viewed.
