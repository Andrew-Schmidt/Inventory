from __future__ import annotations

import os
import re
import sqlite3
import threading
import uuid
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from flask import Flask, abort, after_this_request, flash, jsonify, redirect, render_template, request, send_file, send_from_directory, url_for
from PIL import Image, ImageOps, UnidentifiedImageError

BASE = Path(__file__).resolve().parent


def default_data_dir():
    # V4 and later keep collection data outside the application version folder.
    # This makes upgrades as simple as replacing the app while leaving the catalog alone.
    configured = os.environ.get('CATALOG_DATA')
    if configured:
        return Path(configured).expanduser().resolve()
    if os.name == 'nt':
        return (Path.home() / 'LionelCatalogData').resolve()
    return (Path.home() / '.lionel_train_catalog').resolve()


def legacy_data_candidates():
    candidates = [BASE / 'data']
    downloads = Path.home() / 'Downloads'
    for version in ('v3', 'v2', 'v1'):
        candidates.append(downloads / f'lionel_train_catalog_{version}' / 'lionel_catalog' / 'data')
    return candidates


def migrate_legacy_data(target):
    # Only auto-import when the new permanent data directory has no database yet.
    # Nothing in the old installation is deleted.
    if (target / 'catalog.sqlite3').exists():
        return None
    for source in legacy_data_candidates():
        source = source.resolve()
        if source == target or not (source / 'catalog.sqlite3').exists():
            continue
        target.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, target, dirs_exist_ok=True)
        try:
            (target / 'MIGRATED_FROM.txt').write_text(
                f'Automatically copied from: {source}\nThe original data was left unchanged.\n',
                encoding='utf-8'
            )
        except OSError:
            pass
        return source
    return None


DATA = default_data_dir()
MIGRATED_FROM = migrate_legacy_data(DATA)
PHOTOS = DATA / 'photos'
THUMBS = DATA / 'thumbs'
DB = DATA / 'catalog.sqlite3'
for p in (DATA, PHOTOS, THUMBS):
    p.mkdir(parents=True, exist_ok=True)
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or 'local-catalog-change-if-exposed'
app.config['MAX_CONTENT_LENGTH'] = 120 * 1024 * 1024
ALLOWED = {'jpg', 'jpeg', 'png', 'webp', 'heic', 'heif'}
lock = threading.RLock()


def connect():
    conn = sqlite3.connect(DB, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    return conn


def init_db():
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS groups (id INTEGER PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE UNIQUE);
        CREATE TABLE IF NOT EXISTS trains (
            id INTEGER PRIMARY KEY, name TEXT NOT NULL, group_id INTEGER REFERENCES groups(id) ON DELETE SET NULL,
            description TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, next_number INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS photos (
            id INTEGER PRIMARY KEY, train_id INTEGER NOT NULL REFERENCES trains(id) ON DELETE CASCADE,
            number INTEGER NOT NULL, filename TEXT NOT NULL UNIQUE, original_name TEXT NOT NULL,
            created_at TEXT NOT NULL, UNIQUE(train_id, number)
        );
        CREATE TABLE IF NOT EXISTS train_groups (
            train_id INTEGER NOT NULL REFERENCES trains(id) ON DELETE CASCADE,
            group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
            PRIMARY KEY (train_id, group_id)
        );
        CREATE TABLE IF NOT EXISTS statuses (
            id INTEGER PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE UNIQUE
        );
        CREATE TABLE IF NOT EXISTS train_statuses (
            train_id INTEGER NOT NULL REFERENCES trains(id) ON DELETE CASCADE,
            status_id INTEGER NOT NULL REFERENCES statuses(id) ON DELETE CASCADE,
            PRIMARY KEY (train_id, status_id)
        );
        CREATE INDEX IF NOT EXISTS idx_photos_train ON photos(train_id, number);
        CREATE INDEX IF NOT EXISTS idx_train_groups_group ON train_groups(group_id, train_id);
        CREATE INDEX IF NOT EXISTS idx_train_statuses_status ON train_statuses(status_id, train_id);
        ''')
        columns = {row['name'] for row in db.execute('PRAGMA table_info(trains)')}
        if 'needs_details' not in columns:
            db.execute('ALTER TABLE trains ADD COLUMN needs_details INTEGER NOT NULL DEFAULT 0')
        if 'group_id' in columns:
            db.execute('''INSERT OR IGNORE INTO train_groups(train_id, group_id)
                          SELECT id, group_id FROM trains WHERE group_id IS NOT NULL''')


def clean_name(value, fallback='Train'):
    value = re.sub(r'[^\w .()-]+', '-', value.strip(), flags=re.UNICODE)
    value = re.sub(r'\s+', ' ', value).strip(' .-_')
    return (value[:70] or fallback)


def unique_filename(train_id, name, number):
    # Train id prevents collisions when entries share a name; sequence remains per train.
    return f'{clean_name(name)}_{number:03d}_ID{train_id}.jpg'


def get_train(db, train_id):
    train = db.execute('''SELECT trains.*,
        COALESCE((SELECT GROUP_CONCAT(g.name, ', ')
                  FROM train_groups tg JOIN groups g ON g.id=tg.group_id
                  WHERE tg.train_id=trains.id), '') AS group_names,
        COALESCE((SELECT GROUP_CONCAT(s.name, ', ')
                  FROM train_statuses ts JOIN statuses s ON s.id=ts.status_id
                  WHERE ts.train_id=trains.id), '') AS status_names
        FROM trains WHERE trains.id=?''', (train_id,)).fetchone()
    if train is None: abort(404)
    return train


def train_group_ids(db, train_id):
    return {row['group_id'] for row in db.execute(
        'SELECT group_id FROM train_groups WHERE train_id=?', (train_id,)).fetchall()}


def groups(db):
    return db.execute('''SELECT groups.*, COUNT(train_groups.train_id) AS item_count
        FROM groups LEFT JOIN train_groups ON train_groups.group_id=groups.id
        GROUP BY groups.id ORDER BY groups.name COLLATE NOCASE''').fetchall()


def resolve_groups(db, group_values=None, new_group_name=''):
    selected = set()
    for value in (group_values or []):
        gid = str(value or '').strip()
        if gid.isdigit() and db.execute('SELECT 1 FROM groups WHERE id=?', (int(gid),)).fetchone():
            selected.add(int(gid))
    new_name = new_group_name.strip()[:100]
    if new_name:
        existing = db.execute('SELECT id FROM groups WHERE name=? COLLATE NOCASE', (new_name,)).fetchone()
        if existing:
            selected.add(existing['id'])
        else:
            cur = db.execute('INSERT INTO groups(name) VALUES (?)', (new_name,))
            selected.add(cur.lastrowid)
    return selected


def set_train_groups(db, train_id, group_ids):
    db.execute('DELETE FROM train_groups WHERE train_id=?', (train_id,))
    db.executemany('INSERT INTO train_groups(train_id, group_id) VALUES (?, ?)',
                   [(train_id, gid) for gid in sorted(set(group_ids))])


def train_status_ids(db, train_id):
    return {row['status_id'] for row in db.execute(
        'SELECT status_id FROM train_statuses WHERE train_id=?', (train_id,)).fetchall()}


def statuses(db):
    return db.execute('''SELECT statuses.*, COUNT(train_statuses.train_id) AS item_count
        FROM statuses LEFT JOIN train_statuses ON train_statuses.status_id=statuses.id
        GROUP BY statuses.id ORDER BY statuses.name COLLATE NOCASE''').fetchall()


def resolve_statuses(db, status_values=None, new_status_name=''):
    selected = set()
    for value in (status_values or []):
        sid = str(value or '').strip()
        if sid.isdigit() and db.execute('SELECT 1 FROM statuses WHERE id=?', (int(sid),)).fetchone():
            selected.add(int(sid))
    new_name = new_status_name.strip()[:100]
    if new_name:
        existing = db.execute('SELECT id FROM statuses WHERE name=? COLLATE NOCASE', (new_name,)).fetchone()
        if existing:
            selected.add(existing['id'])
        else:
            cur = db.execute('INSERT INTO statuses(name) VALUES (?)', (new_name,))
            selected.add(cur.lastrowid)
    return selected


def set_train_statuses(db, train_id, status_ids):
    db.execute('DELETE FROM train_statuses WHERE train_id=?', (train_id,))
    db.executemany('INSERT INTO train_statuses(train_id, status_id) VALUES (?, ?)',
                   [(train_id, sid) for sid in sorted(set(status_ids))])


@app.get('/')
def index():
    term = request.args.get('q', '').strip()
    group_id = request.args.get('group', '').strip()
    status_id = request.args.get('status', '').strip()
    details = request.args.get('details', '').strip()
    sql = '''SELECT trains.*, COUNT(DISTINCT photos.id) AS photo_count,
             (SELECT filename FROM photos WHERE train_id=trains.id ORDER BY number LIMIT 1) AS cover,
             COALESCE((SELECT GROUP_CONCAT(g.name, ', ')
                       FROM train_groups tg JOIN groups g ON g.id=tg.group_id
                       WHERE tg.train_id=trains.id), '') AS group_names,
             COALESCE((SELECT GROUP_CONCAT(s.name, ', ')
                       FROM train_statuses ts JOIN statuses s ON s.id=ts.status_id
                       WHERE ts.train_id=trains.id), '') AS status_names
             FROM trains LEFT JOIN photos ON photos.train_id=trains.id WHERE 1=1'''
    args = []
    if term:
        sql += ''' AND (trains.name LIKE ? OR trains.description LIKE ? OR EXISTS (
            SELECT 1 FROM train_groups tg JOIN groups g ON g.id=tg.group_id
            WHERE tg.train_id=trains.id AND g.name LIKE ?) OR EXISTS (
            SELECT 1 FROM train_statuses ts JOIN statuses s ON s.id=ts.status_id
            WHERE ts.train_id=trains.id AND s.name LIKE ?))'''
        args += [f'%{term}%'] * 4
    if details == 'unfinished':
        sql += ' AND trains.needs_details=1'
    elif details == 'complete':
        sql += ' AND trains.needs_details=0'
    if group_id.isdigit():
        sql += ' AND EXISTS (SELECT 1 FROM train_groups tg WHERE tg.train_id=trains.id AND tg.group_id=?)'
        args.append(int(group_id))
    if status_id.isdigit():
        sql += ' AND EXISTS (SELECT 1 FROM train_statuses ts WHERE ts.train_id=trains.id AND ts.status_id=?)'
        args.append(int(status_id))
    sql += ' GROUP BY trains.id ORDER BY trains.id DESC'
    with connect() as db:
        trains = db.execute(sql, args).fetchall()
        all_groups = groups(db)
        all_statuses = statuses(db)
        stats = db.execute('SELECT (SELECT COUNT(*) FROM trains) AS trains, (SELECT COUNT(*) FROM photos) AS photos, (SELECT COUNT(*) FROM trains WHERE needs_details=1) AS unfinished').fetchone()
    return render_template('index.html', trains=trains, groups=all_groups, statuses=all_statuses, stats=stats, q=term, selected_group=group_id, selected_status=status_id, selected_details=details)


@app.route('/new', methods=['GET', 'POST'])
def new_train():
    with connect() as db:
        if request.method == 'POST':
            name = request.form.get('name', '').strip()[:140]
            if not name:
                flash('Enter a name for this train or item.', 'error')
            else:
                group_ids = resolve_groups(db, request.form.getlist('group_ids'), request.form.get('new_group', ''))
                status_ids = resolve_statuses(db, request.form.getlist('status_ids'), request.form.get('new_status', ''))
                cur = db.execute('INSERT INTO trains(name,description,created_at) VALUES (?,?,?)',
                    (name, request.form.get('description', '').strip()[:3000], datetime.now(timezone.utc).isoformat()))
                set_train_groups(db, cur.lastrowid, group_ids)
                set_train_statuses(db, cur.lastrowid, status_ids)
                db.commit()
                return redirect(url_for('detail', train_id=cur.lastrowid))
        return render_template('edit.html', train=None, groups=groups(db), statuses=statuses(db), selected_group_ids=set(), selected_status_ids=set())


@app.route('/capture', methods=['GET', 'POST'])
def capture():
    if request.method == 'GET':
        with connect() as db:
            return render_template('capture.html', groups=groups(db), statuses=statuses(db))
    files = [f for f in request.files.getlist('photos') if f.filename]
    if not files:
        flash('Take or select at least one photo.', 'error')
        return redirect(url_for('capture'))
    valid, errors = validate_images(files)
    if not valid:
        for error in errors[:6]: flash(error, 'error')
        return redirect(url_for('capture'))
    with lock, connect() as db:
        group_ids = resolve_groups(db, request.form.getlist('group_ids'), request.form.get('new_group', ''))
        status_ids = resolve_statuses(db, request.form.getlist('status_ids'), request.form.get('new_status', ''))
        cursor = db.execute('INSERT INTO trains(name,description,created_at,needs_details) VALUES (?,?,?,1)',
                            ('Pending identification', '', datetime.now(timezone.utc).isoformat()))
        train_id = cursor.lastrowid
        set_train_groups(db, train_id, group_ids)
        set_train_statuses(db, train_id, status_ids)
        db.commit()
    saved, save_errors, _ = save_images(train_id, valid)
    errors.extend(save_errors)
    for error in errors[:6]: flash(error, 'error')
    if saved:
        flash(f'Saved {saved} photo(s) to new entry #{train_id}. Add the details now or come back later.', 'success')
        return redirect(url_for('detail', train_id=train_id))
    with connect() as db:
        db.execute('DELETE FROM trains WHERE id=?', (train_id,))
        db.commit()
    return redirect(url_for('capture'))


@app.route('/train/<int:train_id>', methods=['GET'])
def detail(train_id):
    with connect() as db:
        train = get_train(db, train_id)
        photos = db.execute('SELECT * FROM photos WHERE train_id=? ORDER BY number DESC', (train_id,)).fetchall()
    return render_template('detail.html', train=train, photos=photos)


@app.route('/train/<int:train_id>/edit', methods=['GET', 'POST'])
def edit_train(train_id):
    with connect() as db:
        train = get_train(db, train_id)
        if request.method == 'POST':
            name = request.form.get('name', '').strip()[:140]
            if not name:
                flash('Name is required.', 'error')
            else:
                group_ids = resolve_groups(db, request.form.getlist('group_ids'), request.form.get('new_group', ''))
                status_ids = resolve_statuses(db, request.form.getlist('status_ids'), request.form.get('new_status', ''))
                # Existing photographs are renamed when a draft is first identified; renamed
                # entries also keep filename labels in sync with the catalog name.
                with lock:
                    rename_photos(db, train_id, name)
                    db.execute('UPDATE trains SET name=?, description=?, needs_details=0 WHERE id=?',
                        (name, request.form.get('description', '').strip()[:3000], train_id))
                    set_train_groups(db, train_id, group_ids)
                    set_train_statuses(db, train_id, status_ids)
                    db.commit()
                return redirect(url_for('detail', train_id=train_id))
        return render_template('edit.html', train=train, groups=groups(db), statuses=statuses(db), selected_group_ids=train_group_ids(db, train_id), selected_status_ids=train_status_ids(db, train_id))


def process_image(file):
    try:
        img = Image.open(file.stream)
        img.load()
        img = ImageOps.exif_transpose(img).convert('RGB')
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise ValueError('This image could not be opened. Try a JPG, PNG, or WebP photo.') from exc
    img.thumbnail((3200, 3200))
    thumb = img.copy()
    thumb.thumbnail((480, 480))
    return img, thumb


def rename_photos(db, train_id, new_name):
    photos = db.execute('SELECT id, number, filename FROM photos WHERE train_id=? ORDER BY number', (train_id,)).fetchall()
    changes = []
    for photo in photos:
        target = unique_filename(train_id, new_name, photo['number'])
        if photo['filename'] != target:
            changes.append((photo, target))
    if not changes: return
    # Move to unique temporary paths first, so name swaps do not overwrite files.
    staged = []
    try:
        for photo, target in changes:
            token = uuid.uuid4().hex
            tmp_photo = PHOTOS / f'.rename-{token}.jpg'
            tmp_thumb = THUMBS / f'.rename-{token}.jpg'
            (PHOTOS / photo['filename']).rename(tmp_photo)
            (THUMBS / photo['filename']).rename(tmp_thumb)
            staged.append((photo, target, tmp_photo, tmp_thumb))
        for photo, target, tmp_photo, tmp_thumb in staged:
            if (PHOTOS / target).exists() or (THUMBS / target).exists():
                raise OSError(f'Filename already in use: {target}')
            tmp_photo.rename(PHOTOS / target)
            tmp_thumb.rename(THUMBS / target)
            db.execute('UPDATE photos SET filename=? WHERE id=?', (target, photo['id']))
    except (OSError, sqlite3.Error):
        for photo, target, tmp_photo, tmp_thumb in staged:
            for old_dir, tmp_path in ((PHOTOS, tmp_photo), (THUMBS, tmp_thumb)):
                path = tmp_path if tmp_path.exists() else old_dir / target
                if path.exists(): path.rename(old_dir / photo['filename'])
        raise


def validate_images(files):
    valid, errors = [], []
    for file in files:
        if file.filename.rsplit('.', 1)[-1].lower() not in ALLOWED:
            errors.append(f'{file.filename}: unsupported image type')
            continue
        try:
            valid.append((file.filename[:255], *process_image(file)))
        except ValueError as exc:
            errors.append(f'{file.filename}: {exc}')
    return valid, errors


def save_images(train_id, valid):
    errors = []
    with lock, connect() as db:
        db.execute('BEGIN IMMEDIATE')
        train = get_train(db, train_id)
        next_num = train['next_number']
        saved = 0
        label = f'Unlabeled {train_id}' if train['needs_details'] else train['name']
        for original, img, thumb in valid:
            name = unique_filename(train_id, label, next_num)
            while (PHOTOS / name).exists():
                next_num += 1
                name = unique_filename(train_id, label, next_num)
            temp_name = f'.upload-{uuid.uuid4().hex}.jpg'
            tmp, thumb_tmp = PHOTOS / temp_name, THUMBS / temp_name
            try:
                img.save(tmp, 'JPEG', quality=88, optimize=True)
                thumb.save(thumb_tmp, 'JPEG', quality=78, optimize=True)
                os.replace(tmp, PHOTOS / name)
                os.replace(thumb_tmp, THUMBS / name)
                db.execute('INSERT INTO photos(train_id,number,filename,original_name,created_at) VALUES (?,?,?,?,?)',
                           (train_id, next_num, name, original, datetime.now(timezone.utc).isoformat()))
                next_num += 1
                saved += 1
            except (OSError, sqlite3.Error):
                tmp.unlink(missing_ok=True); thumb_tmp.unlink(missing_ok=True)
                (PHOTOS / name).unlink(missing_ok=True); (THUMBS / name).unlink(missing_ok=True)
                errors.append(f'{original}: unable to save')
        db.execute('UPDATE trains SET next_number=? WHERE id=?', (next_num, train_id))
        db.commit()
    return saved, errors, next_num


@app.post('/train/<int:train_id>/photos')
def upload_photos(train_id):
    files = [f for f in request.files.getlist('photos') if f.filename]
    if not files:
        flash('Choose or take at least one photo.', 'error')
        return redirect(url_for('detail', train_id=train_id))
    valid, errors = validate_images(files)
    saved, save_errors, next_num = save_images(train_id, valid)
    errors.extend(save_errors)
    if saved: flash(f'Saved {saved} photo(s). Numbering will continue at {next_num:03d}.', 'success')
    for error in errors[:8]: flash(error, 'error')
    return redirect(url_for('detail', train_id=train_id))


@app.post('/groups')
def add_group():
    name = request.form.get('name', '').strip()[:100]
    if not name:
        flash('Enter a group name.', 'error')
    else:
        try:
            with connect() as db:
                db.execute('INSERT INTO groups(name) VALUES (?)', (name,))
                db.commit()
            flash(f'Added group: {name}', 'success')
        except sqlite3.IntegrityError:
            flash('That group already exists.', 'error')
    return redirect(request.form.get('return_to') if request.form.get('return_to', '').startswith('/') and not request.form.get('return_to', '').startswith('//') else url_for('index'))


@app.post('/groups/<int:group_id>/delete')
def delete_group(group_id):
    return_to = request.form.get('return_to', '')
    destination = return_to if return_to.startswith('/') and not return_to.startswith('//') else url_for('index')
    with connect() as db:
        group = db.execute('SELECT id, name FROM groups WHERE id=?', (group_id,)).fetchone()
        if not group:
            abort(404)
        count = db.execute('SELECT COUNT(*) AS total FROM train_groups WHERE group_id=?', (group_id,)).fetchone()['total']
        if count:
            flash(f"'{group['name']}' still contains {count} item(s). Move those items to another group or Ungrouped before deleting it.", 'error')
            return redirect(destination)
        db.execute('DELETE FROM groups WHERE id=?', (group_id,))
        db.commit()
    flash(f"Removed empty group: {group['name']}", 'success')
    return redirect(destination)


@app.post('/statuses')
def add_status():
    name = request.form.get('name', '').strip()[:100]
    if not name:
        flash('Enter a status name.', 'error')
    else:
        try:
            with connect() as db:
                db.execute('INSERT INTO statuses(name) VALUES (?)', (name,))
                db.commit()
            flash(f'Added status: {name}', 'success')
        except sqlite3.IntegrityError:
            flash('That status already exists.', 'error')
    return redirect(request.form.get('return_to') if request.form.get('return_to', '').startswith('/') and not request.form.get('return_to', '').startswith('//') else url_for('index'))


@app.post('/statuses/<int:status_id>/delete')
def delete_status(status_id):
    return_to = request.form.get('return_to', '')
    destination = return_to if return_to.startswith('/') and not return_to.startswith('//') else url_for('index')
    with connect() as db:
        status_row = db.execute('SELECT id, name FROM statuses WHERE id=?', (status_id,)).fetchone()
        if not status_row:
            abort(404)
        count = db.execute('SELECT COUNT(*) AS total FROM train_statuses WHERE status_id=?', (status_id,)).fetchone()['total']
        if count:
            flash(f"'{status_row['name']}' is still applied to {count} item(s). Remove it from those items before deleting it.", 'error')
            return redirect(destination)
        db.execute('DELETE FROM statuses WHERE id=?', (status_id,))
        db.commit()
    flash(f"Removed empty status: {status_row['name']}", 'success')
    return redirect(destination)


@app.post('/train/<int:train_id>/photo/<int:photo_id>/delete')
def delete_photo(train_id, photo_id):
    with lock, connect() as db:
        get_train(db, train_id)
        photo = db.execute('SELECT * FROM photos WHERE id=? AND train_id=?', (photo_id, train_id)).fetchone()
        if not photo: abort(404)
        db.execute('DELETE FROM photos WHERE id=?', (photo_id,))
        db.commit()
        (PHOTOS / photo['filename']).unlink(missing_ok=True)
        (THUMBS / photo['filename']).unlink(missing_ok=True)
    flash('Photo removed. Existing file numbers are unchanged.', 'success')
    return redirect(url_for('detail', train_id=train_id))


@app.get('/photo/<path:filename>')
def photo(filename):
    return send_from_directory(PHOTOS, filename, as_attachment=request.args.get('download') == '1')


@app.get('/thumb/<path:filename>')
def thumbnail(filename):
    return send_from_directory(THUMBS, filename)



@app.get('/manifest.webmanifest')
def web_manifest():
    response = send_from_directory(BASE / 'static', 'manifest.webmanifest', mimetype='application/manifest+json')
    response.headers['Cache-Control'] = 'no-cache'
    return response


@app.get('/sw.js')
def service_worker():
    response = send_from_directory(BASE / 'static', 'sw.js', mimetype='application/javascript')
    response.headers['Cache-Control'] = 'no-cache'
    response.headers['Service-Worker-Allowed'] = '/'
    return response

@app.get('/settings')
def settings():
    return render_template('settings.html', data_path=str(DATA), migrated_from=str(MIGRATED_FROM) if MIGRATED_FROM else None)


@app.get('/backup')
def backup_catalog():
    # Create a complete, portable ZIP containing the database, photos, and thumbnails.
    # The archive is created outside DATA so it never includes itself.
    tmp = tempfile.NamedTemporaryFile(prefix='lionel-catalog-', suffix='.zip', delete=False)
    tmp_path = Path(tmp.name)
    tmp.close()
    try:
        with lock, zipfile.ZipFile(tmp_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            if DB.exists():
                zf.write(DB, 'catalog.sqlite3')
            for folder, arc_root in ((PHOTOS, 'photos'), (THUMBS, 'thumbs')):
                if folder.exists():
                    for file in folder.rglob('*'):
                        if file.is_file():
                            zf.write(file, f'{arc_root}/{file.relative_to(folder).as_posix()}')
            zf.writestr('BACKUP_INFO.txt', f'Lionel Train Catalog backup\nData source: {DATA}\n')
        stamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')

        @after_this_request
        def cleanup_backup(response):
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:
                pass
            return response

        return send_file(tmp_path, as_attachment=True, download_name=f'lionel_catalog_backup_{stamp}.zip', mimetype='application/zip')
    except Exception:
        tmp_path.unlink(missing_ok=True)
        raise


@app.errorhandler(413)
def too_large(_):
    return 'Upload too large. Upload fewer images at a time (120 MB per batch maximum).', 413


init_db()
if __name__ == '__main__':
    app.run(host=os.environ.get('HOST', '0.0.0.0'), port=int(os.environ.get('PORT', 5000)), debug=False)
