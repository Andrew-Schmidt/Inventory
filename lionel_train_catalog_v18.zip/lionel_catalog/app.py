from __future__ import annotations

import os
import re
import sqlite3
import threading
import uuid
import shutil
import tempfile
import zipfile
import hashlib
import io
import hmac
from functools import wraps
from datetime import datetime, timezone
from pathlib import Path
from flask import Flask, abort, after_this_request, flash, jsonify, redirect, render_template, request, send_file, send_from_directory, url_for
from werkzeug.datastructures import FileStorage
from PIL import Image, ImageOps, UnidentifiedImageError

BASE = Path(__file__).resolve().parent


def default_data_dir():
    # V4 and later keep collection data outside the application version folder.
    # This makes upgrades as simple as replacing the app while leaving the catalog alone.
    configured = os.environ.get('CATALOG_DATA')
    if configured:
        return Path(configured).expanduser().resolve()
    if os.name == 'nt':
        return (Path.home() / 'LionelCatalogData').resolve()
    return (Path.home() / '.lionel_train_catalog').resolve()


def legacy_data_candidates():
    candidates = [BASE / 'data']
    downloads = Path.home() / 'Downloads'
    for version in ('v3', 'v2', 'v1'):
        candidates.append(downloads / f'lionel_train_catalog_{version}' / 'lionel_catalog' / 'data')
    return candidates


def migrate_legacy_data(target):
    # Only auto-import when the new permanent data directory has no database yet.
    # Nothing in the old installation is deleted.
    if (target / 'catalog.sqlite3').exists():
        return None
    for source in legacy_data_candidates():
        source = source.resolve()
        if source == target or not (source / 'catalog.sqlite3').exists():
            continue
        target.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, target, dirs_exist_ok=True)
        try:
            (target / 'MIGRATED_FROM.txt').write_text(
                f'Automatically copied from: {source}\nThe original data was left unchanged.\n',
                encoding='utf-8'
            )
        except OSError:
            pass
        return source
    return None


DATA = default_data_dir()
MIGRATED_FROM = migrate_legacy_data(DATA)
PHOTOS = DATA / 'photos'
THUMBS = DATA / 'thumbs'
INTAKE_ORIGINALS = DATA / 'intake_originals'
INTAKE_THUMBS = DATA / 'intake_thumbs'
DB = DATA / 'catalog.sqlite3'
for p in (DATA, PHOTOS, THUMBS, INTAKE_ORIGINALS, INTAKE_THUMBS):
    p.mkdir(parents=True, exist_ok=True)
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or 'local-catalog-change-if-exposed'
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024 * 1024
API_TOKEN = os.environ.get('LIONEL_API_TOKEN', '').strip()
ALLOWED = {'jpg', 'jpeg', 'png', 'webp', 'heic', 'heif'}
lock = threading.RLock()


def connect():
    conn = sqlite3.connect(DB, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    return conn


def init_db():
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS groups (id INTEGER PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE UNIQUE);
        CREATE TABLE IF NOT EXISTS trains (
            id INTEGER PRIMARY KEY, name TEXT NOT NULL, group_id INTEGER REFERENCES groups(id) ON DELETE SET NULL,
            description TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, next_number INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS photos (
            id INTEGER PRIMARY KEY, train_id INTEGER NOT NULL REFERENCES trains(id) ON DELETE CASCADE,
            number INTEGER NOT NULL, filename TEXT NOT NULL UNIQUE, original_name TEXT NOT NULL,
            created_at TEXT NOT NULL, UNIQUE(train_id, number)
        );
        CREATE TABLE IF NOT EXISTS train_groups (
            train_id INTEGER NOT NULL REFERENCES trains(id) ON DELETE CASCADE,
            group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
            PRIMARY KEY (train_id, group_id)
        );
        CREATE TABLE IF NOT EXISTS statuses (
            id INTEGER PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE UNIQUE
        );
        CREATE TABLE IF NOT EXISTS train_statuses (
            train_id INTEGER NOT NULL REFERENCES trains(id) ON DELETE CASCADE,
            status_id INTEGER NOT NULL REFERENCES statuses(id) ON DELETE CASCADE,
            PRIMARY KEY (train_id, status_id)
        );
        CREATE TABLE IF NOT EXISTS import_history (
            id INTEGER PRIMARY KEY,
            source_hash TEXT NOT NULL UNIQUE,
            source_name TEXT NOT NULL,
            imported_at TEXT NOT NULL,
            item_count INTEGER NOT NULL DEFAULT 0,
            photo_count INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS intake_sessions (
            id INTEGER PRIMARY KEY,
            session_uuid TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            source_ref TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'open',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS intake_groups (
            id INTEGER PRIMARY KEY,
            session_id INTEGER NOT NULL REFERENCES intake_sessions(id) ON DELETE CASCADE,
            group_uuid TEXT NOT NULL UNIQUE,
            label TEXT NOT NULL,
            sequence INTEGER NOT NULL DEFAULT 1,
            marker_photo_id INTEGER,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS intake_photos (
            id INTEGER PRIMARY KEY,
            session_id INTEGER NOT NULL REFERENCES intake_sessions(id) ON DELETE CASCADE,
            sequence INTEGER NOT NULL,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL UNIQUE,
            sha256 TEXT NOT NULL,
            byte_size INTEGER NOT NULL DEFAULT 0,
            mime_type TEXT NOT NULL DEFAULT 'application/octet-stream',
            captured_at TEXT,
            imported_at TEXT NOT NULL,
            source_ref TEXT NOT NULL DEFAULT '',
            is_marker INTEGER NOT NULL DEFAULT 0,
            auto_group_id INTEGER REFERENCES intake_groups(id) ON DELETE SET NULL,
            manual_group_id INTEGER REFERENCES intake_groups(id) ON DELETE SET NULL,
            manual_group_override INTEGER NOT NULL DEFAULT 0,
            UNIQUE(session_id, sequence)
        );
        CREATE INDEX IF NOT EXISTS idx_intake_photos_session ON intake_photos(session_id, sequence);
        CREATE INDEX IF NOT EXISTS idx_intake_photos_hash ON intake_photos(sha256);
        CREATE INDEX IF NOT EXISTS idx_intake_groups_session ON intake_groups(session_id, sequence);
        CREATE INDEX IF NOT EXISTS idx_photos_train ON photos(train_id, number);
        CREATE INDEX IF NOT EXISTS idx_train_groups_group ON train_groups(group_id, train_id);
        CREATE INDEX IF NOT EXISTS idx_train_statuses_status ON train_statuses(status_id, train_id);
        ''')
        columns = {row['name'] for row in db.execute('PRAGMA table_info(trains)')}
        if 'needs_details' not in columns:
            db.execute('ALTER TABLE trains ADD COLUMN needs_details INTEGER NOT NULL DEFAULT 0')
        if 'group_id' in columns:
            db.execute('''INSERT OR IGNORE INTO train_groups(train_id, group_id)
                          SELECT id, group_id FROM trains WHERE group_id IS NOT NULL''')
        if 'physical_uuid' not in columns:
            db.execute('ALTER TABLE trains ADD COLUMN physical_uuid TEXT')
        for row in db.execute('SELECT id FROM trains WHERE physical_uuid IS NULL OR physical_uuid=""').fetchall():
            db.execute('UPDATE trains SET physical_uuid=? WHERE id=?', (str(uuid.uuid4()), row['id']))
        db.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_trains_physical_uuid ON trains(physical_uuid)')


def clean_name(value, fallback='Train'):
    value = re.sub(r'[^\w .()-]+', '-', value.strip(), flags=re.UNICODE)
    value = re.sub(r'\s+', ' ', value).strip(' .-_')
    return (value[:70] or fallback)


def unique_filename(train_id, name, number):
    # Train id prevents collisions when entries share a name; sequence remains per train.
    return f'{clean_name(name)}_{number:03d}_ID{train_id}.jpg'


def get_train(db, train_id):
    train = db.execute('''SELECT trains.*,
        COALESCE((SELECT GROUP_CONCAT(g.name, ', ')
                  FROM train_groups tg JOIN groups g ON g.id=tg.group_id
                  WHERE tg.train_id=trains.id), '') AS group_names,
        COALESCE((SELECT GROUP_CONCAT(s.name, ', ')
                  FROM train_statuses ts JOIN statuses s ON s.id=ts.status_id
                  WHERE ts.train_id=trains.id), '') AS status_names
        FROM trains WHERE trains.id=?''', (train_id,)).fetchone()
    if train is None: abort(404)
    return train


def train_group_ids(db, train_id):
    return {row['group_id'] for row in db.execute(
        'SELECT group_id FROM train_groups WHERE train_id=?', (train_id,)).fetchall()}


def groups(db):
    return db.execute('''SELECT groups.*, COUNT(train_groups.train_id) AS item_count
        FROM groups LEFT JOIN train_groups ON train_groups.group_id=groups.id
        GROUP BY groups.id ORDER BY groups.name COLLATE NOCASE''').fetchall()


def resolve_groups(db, group_values=None, new_group_name=''):
    selected = set()
    for value in (group_values or []):
        gid = str(value or '').strip()
        if gid.isdigit() and db.execute('SELECT 1 FROM groups WHERE id=?', (int(gid),)).fetchone():
            selected.add(int(gid))
    new_name = new_group_name.strip()[:100]
    if new_name:
        existing = db.execute('SELECT id FROM groups WHERE name=? COLLATE NOCASE', (new_name,)).fetchone()
        if existing:
            selected.add(existing['id'])
        else:
            cur = db.execute('INSERT INTO groups(name) VALUES (?)', (new_name,))
            selected.add(cur.lastrowid)
    return selected


def set_train_groups(db, train_id, group_ids):
    db.execute('DELETE FROM train_groups WHERE train_id=?', (train_id,))
    db.executemany('INSERT INTO train_groups(train_id, group_id) VALUES (?, ?)',
                   [(train_id, gid) for gid in sorted(set(group_ids))])


def train_status_ids(db, train_id):
    return {row['status_id'] for row in db.execute(
        'SELECT status_id FROM train_statuses WHERE train_id=?', (train_id,)).fetchall()}


def statuses(db):
    return db.execute('''SELECT statuses.*, COUNT(train_statuses.train_id) AS item_count
        FROM statuses LEFT JOIN train_statuses ON train_statuses.status_id=statuses.id
        GROUP BY statuses.id ORDER BY statuses.name COLLATE NOCASE''').fetchall()


def resolve_statuses(db, status_values=None, new_status_name=''):
    selected = set()
    for value in (status_values or []):
        sid = str(value or '').strip()
        if sid.isdigit() and db.execute('SELECT 1 FROM statuses WHERE id=?', (int(sid),)).fetchone():
            selected.add(int(sid))
    new_name = new_status_name.strip()[:100]
    if new_name:
        existing = db.execute('SELECT id FROM statuses WHERE name=? COLLATE NOCASE', (new_name,)).fetchone()
        if existing:
            selected.add(existing['id'])
        else:
            cur = db.execute('INSERT INTO statuses(name) VALUES (?)', (new_name,))
            selected.add(cur.lastrowid)
    return selected


def set_train_statuses(db, train_id, status_ids):
    db.execute('DELETE FROM train_statuses WHERE train_id=?', (train_id,))
    db.executemany('INSERT INTO train_statuses(train_id, status_id) VALUES (?, ?)',
                   [(train_id, sid) for sid in sorted(set(status_ids))])


def _api_json_error(message, status=400, **extra):
    payload = {'success': False, 'error': message}
    payload.update(extra)
    return jsonify(payload), status


def require_api_token(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not API_TOKEN:
            return _api_json_error('API access is not configured on this server.', 503)
        auth = request.headers.get('Authorization', '')
        supplied = ''
        if auth.lower().startswith('bearer '):
            supplied = auth[7:].strip()
        if not supplied:
            supplied = request.headers.get('X-API-Key', '').strip()
        if not supplied or not hmac.compare_digest(supplied, API_TOKEN):
            return _api_json_error('Invalid or missing API token.', 401)
        return view(*args, **kwargs)
    return wrapped


def _split_api_names(*field_names):
    values = []
    seen = set()
    for field_name in field_names:
        for raw in request.form.getlist(field_name):
            for part in str(raw).split(','):
                name = part.strip()[:100]
                if name and name.casefold() not in seen:
                    values.append(name)
                    seen.add(name.casefold())
    return values


def _resolve_named_labels(db, table, names):
    if table not in {'groups', 'statuses'}:
        raise ValueError('Unsupported label table')
    resolved = []
    for name in names:
        row = db.execute(f'SELECT id, name FROM {table} WHERE name=? COLLATE NOCASE', (name,)).fetchone()
        if row:
            resolved.append((row['id'], row['name'], False))
            continue
        cur = db.execute(f'INSERT INTO {table}(name) VALUES (?)', (name,))
        resolved.append((cur.lastrowid, name, True))
    return resolved


def _api_uploaded_files():
    files = []
    for key in ('photos', 'files'):
        files.extend(f for f in request.files.getlist(key) if f and f.filename)
    return files


def _images_from_zip(upload):
    if not upload or not upload.filename:
        return [], []
    if not upload.filename.lower().endswith('.zip'):
        raise ValueError('archive must be a .zip file')
    found = []
    skipped = []
    upload.stream.seek(0)
    with zipfile.ZipFile(upload.stream, 'r') as zf:
        infos = [i for i in zf.infolist() if not i.is_dir()]
        total = sum(i.file_size for i in infos)
        if total > 4 * 1024 * 1024 * 1024:
            raise ValueError('Archive expands beyond the 4 GB API safety limit.')
        for info in infos:
            normalized = info.filename.replace('\\', '/')
            basename = normalized.rsplit('/', 1)[-1]
            if not basename or basename.startswith('.') or '/__MACOSX/' in f'/{normalized}':
                continue
            ext = basename.rsplit('.', 1)[-1].lower() if '.' in basename else ''
            if ext not in ALLOWED:
                skipped.append(normalized)
                continue
            if info.file_size > 150 * 1024 * 1024:
                skipped.append(f'{normalized} (too large)')
                continue
            found.append(FileStorage(stream=io.BytesIO(zf.read(info)), filename=basename))
    return found, skipped


def _api_absolute_url(endpoint, **values):
    # Build an absolute URL that respects Nginx's forwarded HTTPS scheme.
    path = url_for(endpoint, **values)
    scheme = (request.headers.get('X-Forwarded-Proto') or request.scheme or 'https').split(',')[0].strip()
    return f'{scheme}://{request.host}{path}'


def _api_photo_payload(train_id, row):
    return {
        'number': row['number'],
        'filename': row['filename'],
        'original_name': row['original_name'],
        'download_url': _api_absolute_url('api_get_item_photo', train_id=train_id, number=row['number']),
    }


def _api_item_payload(db, train_id):
    train = get_train(db, train_id)
    photos = db.execute('SELECT number, filename, original_name FROM photos WHERE train_id=? ORDER BY number', (train_id,)).fetchall()
    group_rows = db.execute('SELECT g.name FROM train_groups tg JOIN groups g ON g.id=tg.group_id WHERE tg.train_id=? ORDER BY g.name COLLATE NOCASE', (train_id,)).fetchall()
    status_rows = db.execute('SELECT s.name FROM train_statuses ts JOIN statuses s ON s.id=ts.status_id WHERE ts.train_id=? ORDER BY s.name COLLATE NOCASE', (train_id,)).fetchall()
    return {
        'id': train['id'],
        'physical_uuid': train['physical_uuid'],
        'name': train['name'],
        'description': train['description'],
        'groups': [r['name'] for r in group_rows],
        'statuses': [r['name'] for r in status_rows],
        'photos': [_api_photo_payload(train_id, r) for r in photos],
        'photos_url': _api_absolute_url('api_list_item_photos', train_id=train_id),
        'photos_zip_url': _api_absolute_url('api_get_item_photos_zip', train_id=train_id),
    }


def catalog_query():
    term = request.args.get('q', '').strip()
    group_id = request.args.get('group', '').strip()
    status_id = request.args.get('status', '').strip()
    details = request.args.get('details', '').strip()
    sql = '''SELECT trains.*, COUNT(DISTINCT photos.id) AS photo_count,
             (SELECT filename FROM photos WHERE train_id=trains.id ORDER BY number LIMIT 1) AS cover,
             COALESCE((SELECT GROUP_CONCAT(g.name, ', ')
                       FROM train_groups tg JOIN groups g ON g.id=tg.group_id
                       WHERE tg.train_id=trains.id), '') AS group_names,
             COALESCE((SELECT GROUP_CONCAT(s.name, ', ')
                       FROM train_statuses ts JOIN statuses s ON s.id=ts.status_id
                       WHERE ts.train_id=trains.id), '') AS status_names
             FROM trains LEFT JOIN photos ON photos.train_id=trains.id WHERE 1=1'''
    args = []
    if term:
        sql += ''' AND (trains.name LIKE ? OR trains.description LIKE ? OR EXISTS (
            SELECT 1 FROM train_groups tg JOIN groups g ON g.id=tg.group_id
            WHERE tg.train_id=trains.id AND g.name LIKE ?) OR EXISTS (
            SELECT 1 FROM train_statuses ts JOIN statuses s ON s.id=ts.status_id
            WHERE ts.train_id=trains.id AND s.name LIKE ?))'''
        args += [f'%{term}%'] * 4
    if details == 'unfinished':
        sql += ' AND trains.needs_details=1'
    elif details == 'complete':
        sql += ' AND trains.needs_details=0'
    if group_id.isdigit():
        sql += ' AND EXISTS (SELECT 1 FROM train_groups tg WHERE tg.train_id=trains.id AND tg.group_id=?)'
        args.append(int(group_id))
    if status_id.isdigit():
        sql += ' AND EXISTS (SELECT 1 FROM train_statuses ts WHERE ts.train_id=trains.id AND ts.status_id=?)'
        args.append(int(status_id))
    sql += ' GROUP BY trains.id ORDER BY trains.id DESC'
    with connect() as db:
        trains = db.execute(sql, args).fetchall()
        all_groups = groups(db)
        all_statuses = statuses(db)
        stats = db.execute('SELECT (SELECT COUNT(*) FROM trains) AS trains, (SELECT COUNT(*) FROM photos) AS photos, (SELECT COUNT(*) FROM trains WHERE needs_details=1) AS unfinished').fetchone()
    return dict(trains=trains, groups=all_groups, statuses=all_statuses, stats=stats, q=term,
                selected_group=group_id, selected_status=status_id, selected_details=details)



@app.get('/api/v1/items')
@require_api_token
def api_list_items():
    term = (request.args.get('q') or request.args.get('search') or '').strip()[:200]
    group_filter = request.args.get('group', '').strip()[:100]
    status_filter = request.args.get('status', '').strip()[:100]
    details = request.args.get('details', '').strip().lower()

    try:
        limit = int(request.args.get('limit', 100))
        offset = int(request.args.get('offset', 0))
    except ValueError:
        return _api_json_error('limit and offset must be integers.', 400)
    limit = max(1, min(limit, 500))
    offset = max(0, offset)

    where = ['1=1']
    args = []
    if term:
        like = f'%{term}%'
        where.append('''(trains.name LIKE ? OR trains.description LIKE ? OR EXISTS (
            SELECT 1 FROM train_groups tg JOIN groups g ON g.id=tg.group_id
            WHERE tg.train_id=trains.id AND g.name LIKE ?) OR EXISTS (
            SELECT 1 FROM train_statuses ts JOIN statuses s ON s.id=ts.status_id
            WHERE ts.train_id=trains.id AND s.name LIKE ?))''')
        args.extend([like, like, like, like])

    if details == 'unfinished':
        where.append('trains.needs_details=1')
    elif details == 'complete':
        where.append('trains.needs_details=0')
    elif details not in {'', 'all'}:
        return _api_json_error("details must be 'unfinished', 'complete', or omitted.", 400)

    if group_filter:
        if group_filter.isdigit():
            where.append('''EXISTS (SELECT 1 FROM train_groups tg
                WHERE tg.train_id=trains.id AND tg.group_id=?)''')
            args.append(int(group_filter))
        else:
            where.append('''EXISTS (SELECT 1 FROM train_groups tg JOIN groups g ON g.id=tg.group_id
                WHERE tg.train_id=trains.id AND g.name=? COLLATE NOCASE)''')
            args.append(group_filter)

    if status_filter:
        if status_filter.isdigit():
            where.append('''EXISTS (SELECT 1 FROM train_statuses ts
                WHERE ts.train_id=trains.id AND ts.status_id=?)''')
            args.append(int(status_filter))
        else:
            where.append('''EXISTS (SELECT 1 FROM train_statuses ts JOIN statuses s ON s.id=ts.status_id
                WHERE ts.train_id=trains.id AND s.name=? COLLATE NOCASE)''')
            args.append(status_filter)

    where_sql = ' AND '.join(where)
    with connect() as db:
        total = db.execute(f'SELECT COUNT(*) AS n FROM trains WHERE {where_sql}', args).fetchone()['n']
        rows = db.execute(f'''SELECT trains.id, trains.physical_uuid, trains.name, trains.description, trains.needs_details,
            trains.created_at,
            (SELECT COUNT(*) FROM photos p WHERE p.train_id=trains.id) AS photo_count,
            (SELECT filename FROM photos p WHERE p.train_id=trains.id ORDER BY number LIMIT 1) AS cover_filename
            FROM trains WHERE {where_sql}
            ORDER BY trains.id DESC LIMIT ? OFFSET ?''', args + [limit, offset]).fetchall()

        items = []
        for row in rows:
            group_rows = db.execute('''SELECT g.name FROM train_groups tg JOIN groups g ON g.id=tg.group_id
                WHERE tg.train_id=? ORDER BY g.name COLLATE NOCASE''', (row['id'],)).fetchall()
            status_rows = db.execute('''SELECT s.name FROM train_statuses ts JOIN statuses s ON s.id=ts.status_id
                WHERE ts.train_id=? ORDER BY s.name COLLATE NOCASE''', (row['id'],)).fetchall()
            items.append({
                'id': row['id'],
                'physical_uuid': row['physical_uuid'],
                'name': row['name'],
                'description': row['description'],
                'needs_details': bool(row['needs_details']),
                'created_at': row['created_at'],
                'groups': [r['name'] for r in group_rows],
                'statuses': [r['name'] for r in status_rows],
                'photo_count': row['photo_count'],
                'cover_filename': row['cover_filename'],
            })

    return jsonify({
        'success': True,
        'count': len(items),
        'total': total,
        'limit': limit,
        'offset': offset,
        'filters': {
            'search': term,
            'group': group_filter,
            'status': status_filter,
            'details': details or None,
        },
        'items': items,
    })


@app.get('/api/v1/groups')
@require_api_token
def api_list_groups():
    with connect() as db:
        rows = groups(db)
    return jsonify({
        'success': True,
        'count': len(rows),
        'groups': [
            {'id': row['id'], 'name': row['name'], 'item_count': row['item_count']}
            for row in rows
        ],
    })


@app.get('/api/v1/statuses')
@require_api_token
def api_list_statuses():
    with connect() as db:
        rows = statuses(db)
    return jsonify({
        'success': True,
        'count': len(rows),
        'statuses': [
            {'id': row['id'], 'name': row['name'], 'item_count': row['item_count']}
            for row in rows
        ],
    })


@app.post('/api/v1/items')
@require_api_token
def api_create_item():
    name = request.form.get('name', '').strip()[:140]
    description = request.form.get('description', '').strip()[:3000]
    if not name:
        return _api_json_error('The name field is required.', 400)

    uploads = _api_uploaded_files()
    skipped_archive = []
    archive = request.files.get('archive')
    try:
        archive_files, skipped_archive = _images_from_zip(archive)
    except (zipfile.BadZipFile, ValueError, OSError) as exc:
        return _api_json_error(str(exc), 400)
    uploads.extend(archive_files)
    if not uploads:
        return _api_json_error('Upload at least one image using photos/files or a ZIP in archive.', 400)

    valid, validation_errors = validate_images(uploads)
    if not valid:
        return _api_json_error('No valid images were supplied.', 400,
                               image_errors=validation_errors, archive_skipped=skipped_archive)

    group_names = _split_api_names('groups', 'group')
    status_names = _split_api_names('statuses', 'status')

    with lock, connect() as db:
        db.execute('BEGIN IMMEDIATE')
        group_rows = _resolve_named_labels(db, 'groups', group_names)
        status_rows = _resolve_named_labels(db, 'statuses', status_names)
        cur = db.execute('INSERT INTO trains(name,description,created_at,needs_details,next_number,physical_uuid) VALUES (?,?,?,?,1,?)',
                         (name, description, datetime.now(timezone.utc).isoformat(), 0, str(uuid.uuid4())))
        train_id = cur.lastrowid
        set_train_groups(db, train_id, [r[0] for r in group_rows])
        set_train_statuses(db, train_id, [r[0] for r in status_rows])
        created_groups = [r[1] for r in group_rows if r[2]]
        created_statuses = [r[1] for r in status_rows if r[2]]
        db.commit()

    saved, save_errors, _ = save_images(train_id, valid)
    if not saved:
        with connect() as db:
            db.execute('DELETE FROM trains WHERE id=?', (train_id,))
            db.commit()
        return _api_json_error('The listing was not created because no images could be saved.', 500,
                               image_errors=validation_errors + save_errors)

    with connect() as db:
        payload = _api_item_payload(db, train_id)
    return jsonify({
        'success': True,
        'item': payload,
        'photos_added': saved,
        'groups_created': created_groups,
        'statuses_created': created_statuses,
        'image_errors': validation_errors + save_errors,
        'archive_skipped': skipped_archive
    }), 201


@app.post('/api/v1/items/<int:train_id>/photos')
@require_api_token
def api_add_item_photos(train_id):
    with connect() as db:
        if not db.execute('SELECT 1 FROM trains WHERE id=?', (train_id,)).fetchone():
            return _api_json_error('Item not found.', 404)

    uploads = _api_uploaded_files()
    skipped_archive = []
    try:
        archive_files, skipped_archive = _images_from_zip(request.files.get('archive'))
    except (zipfile.BadZipFile, ValueError, OSError) as exc:
        return _api_json_error(str(exc), 400)
    uploads.extend(archive_files)
    if not uploads:
        return _api_json_error('Upload at least one image using photos/files or a ZIP in archive.', 400)

    valid, validation_errors = validate_images(uploads)
    if not valid:
        return _api_json_error('No valid images were supplied.', 400,
                               image_errors=validation_errors, archive_skipped=skipped_archive)
    saved, save_errors, next_num = save_images(train_id, valid)
    with connect() as db:
        payload = _api_item_payload(db, train_id)
    return jsonify({
        'success': True,
        'item': payload,
        'photos_added': saved,
        'next_number': next_num,
        'image_errors': validation_errors + save_errors,
        'archive_skipped': skipped_archive
    }), 200


@app.get('/api/v1/items/<int:train_id>')
@require_api_token
def api_get_item(train_id):
    with connect() as db:
        if not db.execute('SELECT 1 FROM trains WHERE id=?', (train_id,)).fetchone():
            return _api_json_error('Item not found.', 404)
        return jsonify({'success': True, 'item': _api_item_payload(db, train_id)})


@app.get('/api/v1/items/<int:train_id>/photos')
@require_api_token
def api_list_item_photos(train_id):
    with connect() as db:
        if not db.execute('SELECT 1 FROM trains WHERE id=?', (train_id,)).fetchone():
            return _api_json_error('Item not found.', 404)
        rows = db.execute(
            'SELECT number, filename, original_name, created_at FROM photos WHERE train_id=? ORDER BY number',
            (train_id,)
        ).fetchall()

    photos = []
    for row in rows:
        payload = _api_photo_payload(train_id, row)
        payload['created_at'] = row['created_at']
        payload['available'] = (PHOTOS / Path(row['filename']).name).is_file()
        photos.append(payload)

    return jsonify({
        'success': True,
        'item_id': train_id,
        'count': len(photos),
        'photos': photos,
        'zip_url': _api_absolute_url('api_get_item_photos_zip', train_id=train_id),
    })


@app.get('/api/v1/items/<int:train_id>/photos/<int:number>')
@require_api_token
def api_get_item_photo(train_id, number):
    with connect() as db:
        if not db.execute('SELECT 1 FROM trains WHERE id=?', (train_id,)).fetchone():
            return _api_json_error('Item not found.', 404)
        row = db.execute(
            'SELECT filename FROM photos WHERE train_id=? AND number=?',
            (train_id, number)
        ).fetchone()
    if not row:
        return _api_json_error('Photo not found.', 404)

    filename = Path(row['filename']).name
    photo_path = PHOTOS / filename
    if not photo_path.is_file():
        return _api_json_error('Photo record exists, but the image file is missing.', 404)

    response = send_file(photo_path, mimetype='image/jpeg', as_attachment=False, download_name=filename)
    response.headers['Cache-Control'] = 'private, max-age=3600'
    return response


@app.get('/api/v1/items/<int:train_id>/photos.zip')
@require_api_token
def api_get_item_photos_zip(train_id):
    with connect() as db:
        train = db.execute('SELECT id, name FROM trains WHERE id=?', (train_id,)).fetchone()
        if not train:
            return _api_json_error('Item not found.', 404)
        rows = db.execute(
            'SELECT number, filename FROM photos WHERE train_id=? ORDER BY number',
            (train_id,)
        ).fetchall()

    if not rows:
        return _api_json_error('This item has no photographs.', 404)

    fd, temp_path = tempfile.mkstemp(prefix=f'lionel-item-{train_id}-', suffix='.zip')
    os.close(fd)
    temp_path = Path(temp_path)
    added = 0
    try:
        with zipfile.ZipFile(temp_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            for row in rows:
                filename = Path(row['filename']).name
                photo_path = PHOTOS / filename
                if photo_path.is_file():
                    zf.write(photo_path, arcname=filename)
                    added += 1
        if not added:
            temp_path.unlink(missing_ok=True)
            return _api_json_error('Photo records exist, but no image files are available.', 404)
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise

    @after_this_request
    def cleanup(response):
        temp_path.unlink(missing_ok=True)
        return response

    safe_name = re.sub(r'[^A-Za-z0-9._-]+', '_', train['name']).strip('._') or f'item_{train_id}'
    return send_file(
        temp_path,
        mimetype='application/zip',
        as_attachment=True,
        download_name=f'{safe_name}_photos.zip'
    )


@app.get('/')
@app.get('/view')
def public_catalog():
    return render_template('public_index.html', **catalog_query())


@app.get('/view/train/<int:train_id>')
def public_detail(train_id):
    with connect() as db:
        train = get_train(db, train_id)
        photos = db.execute('SELECT * FROM photos WHERE train_id=? ORDER BY number ASC', (train_id,)).fetchall()
    return render_template('public_detail.html', train=train, photos=photos)




def _intake_capture_time(img):
    try:
        exif = img.getexif()
        raw = exif.get(36867) or exif.get(36868) or exif.get(306)
        if raw:
            value = str(raw).strip()
            try:
                return datetime.strptime(value, '%Y:%m:%d %H:%M:%S').replace(tzinfo=timezone.utc).isoformat()
            except ValueError:
                return value[:64]
    except Exception:
        pass
    return None


def _intake_file_extension(filename):
    ext = Path(filename or '').suffix.lower().lstrip('.')
    if ext == 'jpeg':
        ext = 'jpg'
    return ext if ext in ALLOWED else 'jpg'


def _intake_marker_filename(filename):
    stem = Path(filename or '').stem.casefold().replace('_', ' ').replace('-', ' ')
    return bool(re.search(r'\bnew\s+set\b', stem))


def _rebuild_intake_groups(db, session_id):
    photos = db.execute('SELECT * FROM intake_photos WHERE session_id=? ORDER BY sequence, id', (session_id,)).fetchall()
    marker_ids = [r['id'] for r in photos if r['is_marker']]
    existing = {r['marker_photo_id']: r for r in db.execute(
        'SELECT * FROM intake_groups WHERE session_id=? AND marker_photo_id IS NOT NULL', (session_id,)).fetchall()}

    # Retire groups whose marker was removed. Preserve a group if a manual correction still points at it.
    for marker_id, group in list(existing.items()):
        if marker_id not in marker_ids:
            in_manual_use = db.execute('''SELECT 1 FROM intake_photos
                WHERE session_id=? AND manual_group_override=1 AND manual_group_id=? LIMIT 1''',
                (session_id, group['id'])).fetchone()
            if in_manual_use:
                db.execute('UPDATE intake_groups SET marker_photo_id=NULL WHERE id=?', (group['id'],))
            else:
                db.execute('DELETE FROM intake_groups WHERE id=?', (group['id'],))

    current_group = None
    marker_number = 0
    for photo in photos:
        if photo['is_marker']:
            marker_number += 1
            group = db.execute('SELECT * FROM intake_groups WHERE session_id=? AND marker_photo_id=?',
                               (session_id, photo['id'])).fetchone()
            if group is None:
                cur = db.execute('''INSERT INTO intake_groups(session_id,group_uuid,label,sequence,marker_photo_id,created_at)
                    VALUES (?,?,?,?,?,?)''',
                    (session_id, str(uuid.uuid4()), f'Set {marker_number}', marker_number, photo['id'], datetime.now(timezone.utc).isoformat()))
                current_group = cur.lastrowid
            else:
                current_group = group['id']
                # Keep custom labels, but maintain display order.
                db.execute('UPDATE intake_groups SET sequence=? WHERE id=?', (marker_number, current_group))
            db.execute('UPDATE intake_photos SET auto_group_id=NULL WHERE id=?', (photo['id'],))
        else:
            db.execute('UPDATE intake_photos SET auto_group_id=? WHERE id=?', (current_group, photo['id']))
    db.execute('UPDATE intake_sessions SET updated_at=? WHERE id=?', (datetime.now(timezone.utc).isoformat(), session_id))


def _intake_session_payload(db, session_id, include_photos=True):
    session = db.execute('SELECT * FROM intake_sessions WHERE id=?', (session_id,)).fetchone()
    if not session:
        return None
    group_rows = db.execute('''SELECT g.*,
        (SELECT COUNT(*) FROM intake_photos p WHERE p.session_id=g.session_id AND
          ((p.manual_group_override=1 AND p.manual_group_id=g.id) OR
           (p.manual_group_override=0 AND p.auto_group_id=g.id))) AS photo_count
        FROM intake_groups g WHERE g.session_id=? ORDER BY g.sequence, g.id''', (session_id,)).fetchall()
    payload = {
        'id': session['id'], 'session_uuid': session['session_uuid'], 'name': session['name'],
        'source_ref': session['source_ref'], 'status': session['status'],
        'created_at': session['created_at'], 'updated_at': session['updated_at'],
        'groups': [{'id': g['id'], 'group_uuid': g['group_uuid'], 'label': g['label'],
                    'sequence': g['sequence'], 'photo_count': g['photo_count']} for g in group_rows]
    }
    if include_photos:
        rows = db.execute('''SELECT p.*, ag.label AS auto_group_label, mg.label AS manual_group_label,
            COALESCE(mg.label, ag.label) AS effective_group_label,
            CASE WHEN p.manual_group_override=1 THEN p.manual_group_id ELSE p.auto_group_id END AS effective_group_id
            FROM intake_photos p
            LEFT JOIN intake_groups ag ON ag.id=p.auto_group_id
            LEFT JOIN intake_groups mg ON mg.id=p.manual_group_id
            WHERE p.session_id=? ORDER BY p.sequence,p.id''', (session_id,)).fetchall()
        payload['photos'] = [{
            'id': r['id'], 'sequence': r['sequence'], 'original_name': r['original_name'],
            'sha256': r['sha256'], 'byte_size': r['byte_size'], 'mime_type': r['mime_type'],
            'captured_at': r['captured_at'], 'imported_at': r['imported_at'], 'source_ref': r['source_ref'],
            'is_marker': bool(r['is_marker']), 'manual_group_override': bool(r['manual_group_override']),
            'group_id': r['effective_group_id'], 'group_label': r['effective_group_label'],
            'download_url': _api_absolute_url('api_get_intake_photo', session_id=session_id, photo_id=r['id'])
        } for r in rows]
        payload['photo_count'] = len(payload['photos'])
    return payload


@app.get('/api/v1/intake/sessions')
@require_api_token
def api_list_intake_sessions():
    with connect() as db:
        rows = db.execute('''SELECT s.*, COUNT(p.id) AS photo_count
            FROM intake_sessions s LEFT JOIN intake_photos p ON p.session_id=s.id
            GROUP BY s.id ORDER BY s.id DESC''').fetchall()
    return jsonify({'success': True, 'count': len(rows), 'sessions': [
        {'id': r['id'], 'session_uuid': r['session_uuid'], 'name': r['name'], 'source_ref': r['source_ref'],
         'status': r['status'], 'created_at': r['created_at'], 'updated_at': r['updated_at'],
         'photo_count': r['photo_count'],
         'url': _api_absolute_url('api_get_intake_session', session_id=r['id'])} for r in rows]})


@app.get('/api/v1/intake/sessions/<int:session_id>')
@require_api_token
def api_get_intake_session(session_id):
    with connect() as db:
        payload = _intake_session_payload(db, session_id, include_photos=True)
    if payload is None:
        return _api_json_error('Intake session not found.', 404)
    payload['success'] = True
    return jsonify(payload)


@app.get('/api/v1/intake/sessions/<int:session_id>/photos/<int:photo_id>')
@require_api_token
def api_get_intake_photo(session_id, photo_id):
    with connect() as db:
        photo = db.execute('SELECT * FROM intake_photos WHERE id=? AND session_id=?', (photo_id, session_id)).fetchone()
    if not photo:
        return _api_json_error('Intake photo not found.', 404)
    path = INTAKE_ORIGINALS / photo['stored_name']
    if not path.exists():
        return _api_json_error('Original intake photo file is missing.', 404)
    return send_file(path, mimetype=photo['mime_type'] or 'application/octet-stream',
                     download_name=photo['original_name'], as_attachment=False)


@app.route('/intake', methods=['GET', 'POST'])
def intake_sessions():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()[:140] or f'Intake {datetime.now().strftime("%Y-%m-%d %H:%M")}'
        source_ref = request.form.get('source_ref', '').strip()[:500]
        now = datetime.now(timezone.utc).isoformat()
        with connect() as db:
            cur = db.execute('''INSERT INTO intake_sessions(session_uuid,name,source_ref,status,created_at,updated_at)
                VALUES (?,?,?,?,?,?)''', (str(uuid.uuid4()), name, source_ref, 'open', now, now))
            db.commit()
            sid = cur.lastrowid
        flash('Intake session created. You can add photos in several batches.', 'success')
        return redirect(url_for('intake_session', session_id=sid))
    with connect() as db:
        rows = db.execute('''SELECT s.*, COUNT(p.id) AS photo_count,
            SUM(CASE WHEN p.is_marker=1 THEN 1 ELSE 0 END) AS marker_count
            FROM intake_sessions s LEFT JOIN intake_photos p ON p.session_id=s.id
            GROUP BY s.id ORDER BY s.id DESC''').fetchall()
    return render_template('intake_index.html', sessions=rows)


@app.get('/intake/<int:session_id>')
def intake_session(session_id):
    with connect() as db:
        session = db.execute('SELECT * FROM intake_sessions WHERE id=?', (session_id,)).fetchone()
        if not session:
            abort(404)
        groups_rows = db.execute('SELECT * FROM intake_groups WHERE session_id=? ORDER BY sequence,id', (session_id,)).fetchall()
        photos = db.execute('''SELECT p.*, ag.label AS auto_group_label, mg.label AS manual_group_label,
            CASE WHEN p.manual_group_override=1 THEN p.manual_group_id ELSE p.auto_group_id END AS effective_group_id,
            CASE WHEN p.manual_group_override=1 THEN mg.label ELSE ag.label END AS effective_group_label
            FROM intake_photos p LEFT JOIN intake_groups ag ON ag.id=p.auto_group_id
            LEFT JOIN intake_groups mg ON mg.id=p.manual_group_id
            WHERE p.session_id=? ORDER BY p.sequence,p.id''', (session_id,)).fetchall()
    return render_template('intake_session.html', session=session, groups=groups_rows, photos=photos)


@app.post('/intake/<int:session_id>/upload')
def intake_upload(session_id):
    files = [f for f in request.files.getlist('photos') if f and f.filename]
    if not files:
        flash('Select one or more photographs.', 'error')
        return redirect(url_for('intake_session', session_id=session_id))
    source_ref = request.form.get('source_ref', '').strip()[:500]
    with lock, connect() as db:
        session = db.execute('SELECT * FROM intake_sessions WHERE id=?', (session_id,)).fetchone()
        if not session:
            abort(404)
        next_sequence = (db.execute('SELECT COALESCE(MAX(sequence),0)+1 AS n FROM intake_photos WHERE session_id=?', (session_id,)).fetchone()['n'])
        imported = duplicates = failed = 0
        messages = []
        for file in files:
            try:
                raw = file.read()
                if not raw:
                    raise ValueError('empty file')
                digest = hashlib.sha256(raw).hexdigest()
                prior = db.execute('''SELECT p.id,p.session_id,p.original_name,s.name AS session_name
                    FROM intake_photos p JOIN intake_sessions s ON s.id=p.session_id
                    WHERE p.sha256=? ORDER BY p.id LIMIT 1''', (digest,)).fetchone()
                if prior:
                    duplicates += 1
                    messages.append(f'{file.filename}: duplicate of intake photo #{prior["id"]} in {prior["session_name"]}')
                    continue
                bio = io.BytesIO(raw)
                img = Image.open(bio)
                img.load()
                captured_at = _intake_capture_time(img)
                thumb = ImageOps.exif_transpose(img).convert('RGB')
                thumb.thumbnail((640, 640))
                ext = _intake_file_extension(file.filename)
                stored_name = f'{uuid.uuid4().hex}.{ext}'
                thumb_name = f'{Path(stored_name).stem}.jpg'
                mime = getattr(img, 'get_format_mimetype', lambda: None)() or f'image/{"jpeg" if ext in {"jpg","jpeg"} else ext}'
                tmp_orig = INTAKE_ORIGINALS / f'.upload-{uuid.uuid4().hex}'
                tmp_thumb = INTAKE_THUMBS / f'.upload-{uuid.uuid4().hex}.jpg'
                tmp_orig.write_bytes(raw)
                thumb.save(tmp_thumb, 'JPEG', quality=82, optimize=True)
                os.replace(tmp_orig, INTAKE_ORIGINALS / stored_name)
                os.replace(tmp_thumb, INTAKE_THUMBS / thumb_name)
                is_marker = 1 if _intake_marker_filename(file.filename) else 0
                db.execute('''INSERT INTO intake_photos(session_id,sequence,original_name,stored_name,sha256,byte_size,mime_type,
                    captured_at,imported_at,source_ref,is_marker) VALUES (?,?,?,?,?,?,?,?,?,?,?)''',
                    (session_id, next_sequence, file.filename[:255], stored_name, digest, len(raw), mime,
                     captured_at, datetime.now(timezone.utc).isoformat(), source_ref or session['source_ref'], is_marker))
                next_sequence += 1
                imported += 1
            except Exception as exc:
                failed += 1
                messages.append(f'{file.filename}: could not import ({exc})')
        _rebuild_intake_groups(db, session_id)
        db.commit()
    if imported:
        flash(f'Imported {imported} original photo(s). You can upload another batch at any time.', 'success')
    if duplicates:
        flash(f'Skipped {duplicates} exact duplicate photo(s).', 'error')
    if failed:
        flash(f'{failed} photo(s) could not be imported.', 'error')
    for msg in messages[:6]:
        flash(msg, 'error')
    return redirect(url_for('intake_session', session_id=session_id))


@app.get('/intake/<int:session_id>/photo/<int:photo_id>/thumb')
def intake_thumb(session_id, photo_id):
    with connect() as db:
        row = db.execute('SELECT stored_name FROM intake_photos WHERE id=? AND session_id=?', (photo_id, session_id)).fetchone()
    if not row:
        abort(404)
    path = INTAKE_THUMBS / f'{Path(row["stored_name"]).stem}.jpg'
    if not path.exists():
        abort(404)
    return send_file(path, mimetype='image/jpeg')


@app.get('/intake/<int:session_id>/photo/<int:photo_id>/original')
def intake_original(session_id, photo_id):
    with connect() as db:
        row = db.execute('SELECT * FROM intake_photos WHERE id=? AND session_id=?', (photo_id, session_id)).fetchone()
    if not row:
        abort(404)
    path = INTAKE_ORIGINALS / row['stored_name']
    if not path.exists():
        abort(404)
    return send_file(path, mimetype=row['mime_type'] or 'application/octet-stream', download_name=row['original_name'])


@app.post('/intake/<int:session_id>/photo/<int:photo_id>/marker')
def intake_toggle_marker(session_id, photo_id):
    with lock, connect() as db:
        row = db.execute('SELECT is_marker FROM intake_photos WHERE id=? AND session_id=?', (photo_id, session_id)).fetchone()
        if not row:
            abort(404)
        new_value = 0 if row['is_marker'] else 1
        db.execute('UPDATE intake_photos SET is_marker=? WHERE id=?', (new_value, photo_id))
        _rebuild_intake_groups(db, session_id)
        db.commit()
    flash('NEW SET marker updated and automatic grouping recalculated.', 'success')
    return redirect(url_for('intake_session', session_id=session_id))


@app.post('/intake/<int:session_id>/photo/<int:photo_id>/group')
def intake_assign_group(session_id, photo_id):
    choice = request.form.get('group_id', 'auto').strip()
    with connect() as db:
        photo = db.execute('SELECT id FROM intake_photos WHERE id=? AND session_id=?', (photo_id, session_id)).fetchone()
        if not photo:
            abort(404)
        if choice == 'auto':
            db.execute('UPDATE intake_photos SET manual_group_override=0,manual_group_id=NULL WHERE id=?', (photo_id,))
        elif choice == 'none':
            db.execute('UPDATE intake_photos SET manual_group_override=1,manual_group_id=NULL WHERE id=?', (photo_id,))
        elif choice.isdigit() and db.execute('SELECT 1 FROM intake_groups WHERE id=? AND session_id=?', (int(choice), session_id)).fetchone():
            db.execute('UPDATE intake_photos SET manual_group_override=1,manual_group_id=? WHERE id=?', (int(choice), photo_id))
        else:
            flash('That intake group does not exist.', 'error')
            return redirect(url_for('intake_session', session_id=session_id))
        db.execute('UPDATE intake_sessions SET updated_at=? WHERE id=?', (datetime.now(timezone.utc).isoformat(), session_id))
        db.commit()
    flash('Photo grouping correction saved.', 'success')
    return redirect(url_for('intake_session', session_id=session_id))


@app.post('/intake/<int:session_id>/group/<int:group_id>/rename')
def intake_rename_group(session_id, group_id):
    label = request.form.get('label', '').strip()[:100]
    if not label:
        flash('Enter a set/group label.', 'error')
        return redirect(url_for('intake_session', session_id=session_id))
    with connect() as db:
        cur = db.execute('UPDATE intake_groups SET label=? WHERE id=? AND session_id=?', (label, group_id, session_id))
        if cur.rowcount == 0:
            abort(404)
        db.execute('UPDATE intake_sessions SET updated_at=? WHERE id=?', (datetime.now(timezone.utc).isoformat(), session_id))
        db.commit()
    flash('Set/group label updated.', 'success')
    return redirect(url_for('intake_session', session_id=session_id))


@app.post('/intake/<int:session_id>/status')
def intake_set_status(session_id):
    status = request.form.get('status', '').strip().lower()
    if status not in {'open', 'review'}:
        flash('Invalid intake status.', 'error')
        return redirect(url_for('intake_session', session_id=session_id))
    with connect() as db:
        cur = db.execute('UPDATE intake_sessions SET status=?,updated_at=? WHERE id=?',
                         (status, datetime.now(timezone.utc).isoformat(), session_id))
        if cur.rowcount == 0:
            abort(404)
        db.commit()
    flash('Intake session status updated.', 'success')
    return redirect(url_for('intake_session', session_id=session_id))

@app.get('/manage')
def index():
    return render_template('index.html', **catalog_query())


@app.get('/robots.txt')
def robots_txt():
    body = 'User-agent: *\nDisallow: /manage\nDisallow: /capture\nDisallow: /new\nDisallow: /settings\nDisallow: /train/\nDisallow: /intake\nAllow: /view\nAllow: /\n'
    return app.response_class(body, mimetype='text/plain')


@app.route('/new', methods=['GET', 'POST'])
def new_train():
    with connect() as db:
        if request.method == 'POST':
            name = request.form.get('name', '').strip()[:140]
            if not name:
                flash('Enter a name for this train or item.', 'error')
            else:
                group_ids = resolve_groups(db, request.form.getlist('group_ids'), request.form.get('new_group', ''))
                status_ids = resolve_statuses(db, request.form.getlist('status_ids'), request.form.get('new_status', ''))
                cur = db.execute('INSERT INTO trains(name,description,created_at,physical_uuid) VALUES (?,?,?,?)',
                    (name, request.form.get('description', '').strip()[:3000], datetime.now(timezone.utc).isoformat(), str(uuid.uuid4())))
                set_train_groups(db, cur.lastrowid, group_ids)
                set_train_statuses(db, cur.lastrowid, status_ids)
                db.commit()
                return redirect(url_for('detail', train_id=cur.lastrowid))
        return render_template('edit.html', train=None, groups=groups(db), statuses=statuses(db), selected_group_ids=set(), selected_status_ids=set())


@app.route('/capture', methods=['GET', 'POST'])
def capture():
    if request.method == 'GET':
        with connect() as db:
            return render_template('capture.html', groups=groups(db), statuses=statuses(db))
    files = [f for f in request.files.getlist('photos') if f.filename]
    if not files:
        flash('Take or select at least one photo.', 'error')
        return redirect(url_for('capture'))
    valid, errors = validate_images(files)
    if not valid:
        for error in errors[:6]: flash(error, 'error')
        return redirect(url_for('capture'))
    with lock, connect() as db:
        group_ids = resolve_groups(db, request.form.getlist('group_ids'), request.form.get('new_group', ''))
        status_ids = resolve_statuses(db, request.form.getlist('status_ids'), request.form.get('new_status', ''))
        cursor = db.execute('INSERT INTO trains(name,description,created_at,needs_details,physical_uuid) VALUES (?,?,?,1,?)',
                            ('Pending identification', '', datetime.now(timezone.utc).isoformat(), str(uuid.uuid4())))
        train_id = cursor.lastrowid
        set_train_groups(db, train_id, group_ids)
        set_train_statuses(db, train_id, status_ids)
        db.commit()
    saved, save_errors, _ = save_images(train_id, valid)
    errors.extend(save_errors)
    for error in errors[:6]: flash(error, 'error')
    if saved:
        flash(f'Saved {saved} photo(s) to new entry #{train_id}. Add the details now or come back later.', 'success')
        return redirect(url_for('detail', train_id=train_id))
    with connect() as db:
        db.execute('DELETE FROM trains WHERE id=?', (train_id,))
        db.commit()
    return redirect(url_for('capture'))


@app.route('/train/<int:train_id>', methods=['GET'])
def detail(train_id):
    with connect() as db:
        train = get_train(db, train_id)
        photos = db.execute('SELECT * FROM photos WHERE train_id=? ORDER BY number DESC', (train_id,)).fetchall()
    return render_template('detail.html', train=train, photos=photos)


@app.route('/train/<int:train_id>/edit', methods=['GET', 'POST'])
def edit_train(train_id):
    with connect() as db:
        train = get_train(db, train_id)
        if request.method == 'POST':
            name = request.form.get('name', '').strip()[:140]
            if not name:
                flash('Name is required.', 'error')
            else:
                group_ids = resolve_groups(db, request.form.getlist('group_ids'), request.form.get('new_group', ''))
                status_ids = resolve_statuses(db, request.form.getlist('status_ids'), request.form.get('new_status', ''))
                # Existing photographs are renamed when a draft is first identified; renamed
                # entries also keep filename labels in sync with the catalog name.
                with lock:
                    rename_photos(db, train_id, name)
                    db.execute('UPDATE trains SET name=?, description=?, needs_details=0 WHERE id=?',
                        (name, request.form.get('description', '').strip()[:3000], train_id))
                    set_train_groups(db, train_id, group_ids)
                    set_train_statuses(db, train_id, status_ids)
                    db.commit()
                return redirect(url_for('detail', train_id=train_id))
        return render_template('edit.html', train=train, groups=groups(db), statuses=statuses(db), selected_group_ids=train_group_ids(db, train_id), selected_status_ids=train_status_ids(db, train_id))


def process_image(file):
    try:
        img = Image.open(file.stream)
        img.load()
        img = ImageOps.exif_transpose(img).convert('RGB')
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise ValueError('This image could not be opened. Try a JPG, PNG, or WebP photo.') from exc
    img.thumbnail((3200, 3200))
    thumb = img.copy()
    thumb.thumbnail((480, 480))
    return img, thumb


def rename_photos(db, train_id, new_name):
    photos = db.execute('SELECT id, number, filename FROM photos WHERE train_id=? ORDER BY number', (train_id,)).fetchall()
    changes = []
    for photo in photos:
        target = unique_filename(train_id, new_name, photo['number'])
        if photo['filename'] != target:
            changes.append((photo, target))
    if not changes: return
    # Move to unique temporary paths first, so name swaps do not overwrite files.
    staged = []
    try:
        for photo, target in changes:
            token = uuid.uuid4().hex
            tmp_photo = PHOTOS / f'.rename-{token}.jpg'
            tmp_thumb = THUMBS / f'.rename-{token}.jpg'
            (PHOTOS / photo['filename']).rename(tmp_photo)
            (THUMBS / photo['filename']).rename(tmp_thumb)
            staged.append((photo, target, tmp_photo, tmp_thumb))
        for photo, target, tmp_photo, tmp_thumb in staged:
            if (PHOTOS / target).exists() or (THUMBS / target).exists():
                raise OSError(f'Filename already in use: {target}')
            tmp_photo.rename(PHOTOS / target)
            tmp_thumb.rename(THUMBS / target)
            db.execute('UPDATE photos SET filename=? WHERE id=?', (target, photo['id']))
    except (OSError, sqlite3.Error):
        for photo, target, tmp_photo, tmp_thumb in staged:
            for old_dir, tmp_path in ((PHOTOS, tmp_photo), (THUMBS, tmp_thumb)):
                path = tmp_path if tmp_path.exists() else old_dir / target
                if path.exists(): path.rename(old_dir / photo['filename'])
        raise


def validate_images(files):
    valid, errors = [], []
    for file in files:
        if file.filename.rsplit('.', 1)[-1].lower() not in ALLOWED:
            errors.append(f'{file.filename}: unsupported image type')
            continue
        try:
            valid.append((file.filename[:255], *process_image(file)))
        except ValueError as exc:
            errors.append(f'{file.filename}: {exc}')
    return valid, errors


def save_images(train_id, valid):
    errors = []
    with lock, connect() as db:
        db.execute('BEGIN IMMEDIATE')
        train = get_train(db, train_id)
        next_num = train['next_number']
        saved = 0
        label = f'Unlabeled {train_id}' if train['needs_details'] else train['name']
        for original, img, thumb in valid:
            name = unique_filename(train_id, label, next_num)
            while (PHOTOS / name).exists():
                next_num += 1
                name = unique_filename(train_id, label, next_num)
            temp_name = f'.upload-{uuid.uuid4().hex}.jpg'
            tmp, thumb_tmp = PHOTOS / temp_name, THUMBS / temp_name
            try:
                img.save(tmp, 'JPEG', quality=88, optimize=True)
                thumb.save(thumb_tmp, 'JPEG', quality=78, optimize=True)
                os.replace(tmp, PHOTOS / name)
                os.replace(thumb_tmp, THUMBS / name)
                db.execute('INSERT INTO photos(train_id,number,filename,original_name,created_at) VALUES (?,?,?,?,?)',
                           (train_id, next_num, name, original, datetime.now(timezone.utc).isoformat()))
                next_num += 1
                saved += 1
            except (OSError, sqlite3.Error):
                tmp.unlink(missing_ok=True); thumb_tmp.unlink(missing_ok=True)
                (PHOTOS / name).unlink(missing_ok=True); (THUMBS / name).unlink(missing_ok=True)
                errors.append(f'{original}: unable to save')
        db.execute('UPDATE trains SET next_number=? WHERE id=?', (next_num, train_id))
        db.commit()
    return saved, errors, next_num


@app.post('/train/<int:train_id>/photos')
def upload_photos(train_id):
    files = [f for f in request.files.getlist('photos') if f.filename]
    if not files:
        flash('Choose or take at least one photo.', 'error')
        return redirect(url_for('detail', train_id=train_id))
    valid, errors = validate_images(files)
    saved, save_errors, next_num = save_images(train_id, valid)
    errors.extend(save_errors)
    if saved: flash(f'Saved {saved} photo(s). Numbering will continue at {next_num:03d}.', 'success')
    for error in errors[:8]: flash(error, 'error')
    return redirect(url_for('detail', train_id=train_id))


@app.post('/groups')
def add_group():
    name = request.form.get('name', '').strip()[:100]
    if not name:
        flash('Enter a group name.', 'error')
    else:
        try:
            with connect() as db:
                db.execute('INSERT INTO groups(name) VALUES (?)', (name,))
                db.commit()
            flash(f'Added group: {name}', 'success')
        except sqlite3.IntegrityError:
            flash('That group already exists.', 'error')
    return redirect(request.form.get('return_to') if request.form.get('return_to', '').startswith('/') and not request.form.get('return_to', '').startswith('//') else url_for('index'))


@app.post('/groups/<int:group_id>/delete')
def delete_group(group_id):
    return_to = request.form.get('return_to', '')
    destination = return_to if return_to.startswith('/') and not return_to.startswith('//') else url_for('index')
    with connect() as db:
        group = db.execute('SELECT id, name FROM groups WHERE id=?', (group_id,)).fetchone()
        if not group:
            abort(404)
        count = db.execute('SELECT COUNT(*) AS total FROM train_groups WHERE group_id=?', (group_id,)).fetchone()['total']
        if count:
            flash(f"'{group['name']}' still contains {count} item(s). Move those items to another group or Ungrouped before deleting it.", 'error')
            return redirect(destination)
        db.execute('DELETE FROM groups WHERE id=?', (group_id,))
        db.commit()
    flash(f"Removed empty group: {group['name']}", 'success')
    return redirect(destination)


@app.post('/statuses')
def add_status():
    name = request.form.get('name', '').strip()[:100]
    if not name:
        flash('Enter a status name.', 'error')
    else:
        try:
            with connect() as db:
                db.execute('INSERT INTO statuses(name) VALUES (?)', (name,))
                db.commit()
            flash(f'Added status: {name}', 'success')
        except sqlite3.IntegrityError:
            flash('That status already exists.', 'error')
    return redirect(request.form.get('return_to') if request.form.get('return_to', '').startswith('/') and not request.form.get('return_to', '').startswith('//') else url_for('index'))


@app.post('/statuses/<int:status_id>/delete')
def delete_status(status_id):
    return_to = request.form.get('return_to', '')
    destination = return_to if return_to.startswith('/') and not return_to.startswith('//') else url_for('index')
    with connect() as db:
        status_row = db.execute('SELECT id, name FROM statuses WHERE id=?', (status_id,)).fetchone()
        if not status_row:
            abort(404)
        count = db.execute('SELECT COUNT(*) AS total FROM train_statuses WHERE status_id=?', (status_id,)).fetchone()['total']
        if count:
            flash(f"'{status_row['name']}' is still applied to {count} item(s). Remove it from those items before deleting it.", 'error')
            return redirect(destination)
        db.execute('DELETE FROM statuses WHERE id=?', (status_id,))
        db.commit()
    flash(f"Removed empty status: {status_row['name']}", 'success')
    return redirect(destination)


@app.post('/train/<int:train_id>/delete')
def delete_train(train_id):
    with lock, connect() as db:
        train = get_train(db, train_id)
        photos = db.execute('SELECT filename FROM photos WHERE train_id=?', (train_id,)).fetchall()
        db.execute('DELETE FROM trains WHERE id=?', (train_id,))
        db.commit()

    for photo in photos:
        (PHOTOS / photo['filename']).unlink(missing_ok=True)
        (THUMBS / photo['filename']).unlink(missing_ok=True)

    label = f"Unlabeled item #{train_id}" if train['needs_details'] else train['name']
    flash(f"Deleted listing: {label}", 'success')
    return redirect(url_for('index'))


@app.post('/train/<int:train_id>/photo/<int:photo_id>/delete')
def delete_photo(train_id, photo_id):
    with lock, connect() as db:
        get_train(db, train_id)
        photo = db.execute('SELECT * FROM photos WHERE id=? AND train_id=?', (photo_id, train_id)).fetchone()
        if not photo: abort(404)
        db.execute('DELETE FROM photos WHERE id=?', (photo_id,))
        db.commit()
        (PHOTOS / photo['filename']).unlink(missing_ok=True)
        (THUMBS / photo['filename']).unlink(missing_ok=True)
    flash('Photo removed. Existing file numbers are unchanged.', 'success')
    return redirect(url_for('detail', train_id=train_id))


@app.get('/photo/<path:filename>')
def photo(filename):
    return send_from_directory(PHOTOS, filename, as_attachment=request.args.get('download') == '1')


@app.get('/thumb/<path:filename>')
def thumbnail(filename):
    return send_from_directory(THUMBS, filename)



@app.get('/manifest.webmanifest')
def web_manifest():
    response = send_from_directory(BASE / 'static', 'manifest.webmanifest', mimetype='application/manifest+json')
    response.headers['Cache-Control'] = 'no-cache'
    return response


@app.get('/sw.js')
def service_worker():
    response = send_from_directory(BASE / 'static', 'sw.js', mimetype='application/javascript')
    response.headers['Cache-Control'] = 'no-cache'
    response.headers['Service-Worker-Allowed'] = '/'
    return response


def _zip_member_for(zf, data_root, folder, filename):
    """Find a data file without extracting untrusted paths to disk."""
    filename = str(filename or '').replace('\\', '/').split('/')[-1]
    if not filename:
        return None
    preferred = f"{data_root}{folder}/{filename}" if data_root else f"{folder}/{filename}"
    names = set(zf.namelist())
    if preferred in names:
        return preferred
    suffix = f"/{folder}/{filename}"
    matches = [name for name in names if name.endswith(suffix) or name == f"{folder}/{filename}"]
    return matches[0] if len(matches) == 1 else None


def _source_table_exists(db, name):
    return db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone() is not None


def _legacy_group_ids(src, train_id, legacy_group_id):
    ids = set()
    if _source_table_exists(src, 'train_groups'):
        ids.update(row['group_id'] for row in src.execute(
            'SELECT group_id FROM train_groups WHERE train_id=?', (train_id,)).fetchall())
    if legacy_group_id is not None:
        ids.add(legacy_group_id)
    return ids


def import_legacy_zip(upload):
    """Merge a V1-V12 backup/project ZIP into the current catalog."""
    temp = tempfile.NamedTemporaryFile(prefix='lionel-import-', suffix='.zip', delete=False)
    temp_path = Path(temp.name)
    created_files = []
    try:
        hasher = hashlib.sha256()
        while True:
            chunk = upload.stream.read(1024 * 1024)
            if not chunk:
                break
            temp.write(chunk)
            hasher.update(chunk)
        temp.close()
        source_hash = hasher.hexdigest()

        with connect() as db:
            prior = db.execute('SELECT * FROM import_history WHERE source_hash=?', (source_hash,)).fetchone()
            if prior:
                return {'duplicate': True, 'items': prior['item_count'], 'photos': prior['photo_count']}

        with zipfile.ZipFile(temp_path, 'r') as zf:
            # Protect the server from zip bombs. The app is intended for photo archives,
            # but a wildly inflated archive should still be rejected.
            total_uncompressed = sum(info.file_size for info in zf.infolist())
            if total_uncompressed > 8 * 1024 * 1024 * 1024:
                raise ValueError('Archive expands beyond the 8 GB import safety limit.')

            db_members = [n for n in zf.namelist() if n.replace('\\', '/').endswith('catalog.sqlite3')]
            if not db_members:
                raise ValueError('No catalog.sqlite3 was found. Choose a ZIP of the old project or its data folder.')
            # Prefer a database living in a data folder; otherwise accept backup ZIP root.
            db_member = sorted(db_members, key=lambda n: (0 if '/data/' in f'/{n}' else 1, len(n)))[0]
            normalized = db_member.replace('\\', '/')
            data_root = normalized[:-len('catalog.sqlite3')]

            legacy_db_path = Path(tempfile.mkstemp(prefix='lionel-legacy-', suffix='.sqlite3')[1])
            try:
                legacy_db_path.write_bytes(zf.read(db_member))
                src = sqlite3.connect(legacy_db_path)
                src.row_factory = sqlite3.Row
                try:
                    required = {'trains', 'photos'}
                    present = {row['name'] for row in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                    if not required.issubset(present):
                        raise ValueError('The SQLite file does not look like a Lionel Catalog database.')

                    group_names = {}
                    if 'groups' in present:
                        group_names = {row['id']: row['name'] for row in src.execute('SELECT id,name FROM groups')}
                    status_names = {}
                    if 'statuses' in present:
                        status_names = {row['id']: row['name'] for row in src.execute('SELECT id,name FROM statuses')}

                    imported_items = 0
                    imported_photos = 0
                    with lock, connect() as dst:
                        try:
                            dst.execute('BEGIN')
                            dst_group_ids = {row['name'].casefold(): row['id'] for row in dst.execute('SELECT id,name FROM groups')}
                            dst_status_ids = {row['name'].casefold(): row['id'] for row in dst.execute('SELECT id,name FROM statuses')}

                            for old_train in src.execute('SELECT * FROM trains ORDER BY id'):
                                old_keys = set(old_train.keys())
                                name = (old_train['name'] or 'Imported item')[:140]
                                description = (old_train['description'] or '')[:3000] if 'description' in old_keys else ''
                                created_at = old_train['created_at'] if 'created_at' in old_keys and old_train['created_at'] else datetime.now(timezone.utc).isoformat()
                                needs_details = int(old_train['needs_details']) if 'needs_details' in old_keys else 0
                                cur = dst.execute(
                                    'INSERT INTO trains(name,description,created_at,needs_details,next_number,physical_uuid) VALUES (?,?,?,?,1,?)',
                                    (name, description, created_at, needs_details, str(uuid.uuid4()))
                                )
                                new_train_id = cur.lastrowid
                                imported_items += 1

                                legacy_gid = old_train['group_id'] if 'group_id' in old_keys else None
                                for old_gid in _legacy_group_ids(src, old_train['id'], legacy_gid):
                                    group_name = group_names.get(old_gid)
                                    if not group_name:
                                        continue
                                    key = group_name.casefold()
                                    gid = dst_group_ids.get(key)
                                    if gid is None:
                                        gid = dst.execute('INSERT INTO groups(name) VALUES (?)', (group_name,)).lastrowid
                                        dst_group_ids[key] = gid
                                    dst.execute('INSERT OR IGNORE INTO train_groups(train_id,group_id) VALUES (?,?)', (new_train_id, gid))

                                if 'train_statuses' in present:
                                    for rel in src.execute('SELECT status_id FROM train_statuses WHERE train_id=?', (old_train['id'],)):
                                        status_name = status_names.get(rel['status_id'])
                                        if not status_name:
                                            continue
                                        key = status_name.casefold()
                                        sid = dst_status_ids.get(key)
                                        if sid is None:
                                            sid = dst.execute('INSERT INTO statuses(name) VALUES (?)', (status_name,)).lastrowid
                                            dst_status_ids[key] = sid
                                        dst.execute('INSERT OR IGNORE INTO train_statuses(train_id,status_id) VALUES (?,?)', (new_train_id, sid))

                                max_number = 0
                                for old_photo in src.execute('SELECT * FROM photos WHERE train_id=? ORDER BY number', (old_train['id'],)):
                                    number = int(old_photo['number'])
                                    max_number = max(max_number, number)
                                    old_filename = old_photo['filename']
                                    photo_member = _zip_member_for(zf, data_root, 'photos', old_filename)
                                    if not photo_member:
                                        continue
                                    target_name = unique_filename(new_train_id, name, number)
                                    # Number collisions within malformed legacy DBs are skipped rather than replacing data.
                                    if dst.execute('SELECT 1 FROM photos WHERE train_id=? AND number=?', (new_train_id, number)).fetchone():
                                        continue
                                    photo_bytes = zf.read(photo_member)
                                    photo_path = PHOTOS / target_name
                                    thumb_path = THUMBS / target_name
                                    photo_path.write_bytes(photo_bytes)
                                    created_files.append(photo_path)

                                    thumb_member = _zip_member_for(zf, data_root, 'thumbs', old_filename)
                                    if thumb_member:
                                        thumb_path.write_bytes(zf.read(thumb_member))
                                    else:
                                        with Image.open(io.BytesIO(photo_bytes)) as imported_img:
                                            imported_img = ImageOps.exif_transpose(imported_img).convert('RGB')
                                            imported_img.thumbnail((480, 480))
                                            imported_img.save(thumb_path, 'JPEG', quality=82, optimize=True)
                                    created_files.append(thumb_path)

                                    dst.execute(
                                        'INSERT INTO photos(train_id,number,filename,original_name,created_at) VALUES (?,?,?,?,?)',
                                        (new_train_id, number, target_name,
                                         old_photo['original_name'] if 'original_name' in old_photo.keys() else old_filename,
                                         old_photo['created_at'] if 'created_at' in old_photo.keys() else created_at)
                                    )
                                    imported_photos += 1

                                dst.execute('UPDATE trains SET next_number=? WHERE id=?', (max_number + 1 if max_number else 1, new_train_id))

                            dst.execute(
                                'INSERT INTO import_history(source_hash,source_name,imported_at,item_count,photo_count) VALUES (?,?,?,?,?)',
                                (source_hash, upload.filename or 'legacy-catalog.zip', datetime.now(timezone.utc).isoformat(), imported_items, imported_photos)
                            )
                            dst.commit()
                        except Exception:
                            dst.rollback()
                            for path in reversed(created_files):
                                try:
                                    path.unlink(missing_ok=True)
                                except OSError:
                                    pass
                            raise
                    return {'duplicate': False, 'items': imported_items, 'photos': imported_photos}
                finally:
                    src.close()
            finally:
                legacy_db_path.unlink(missing_ok=True)
    finally:
        try:
            temp.close()
        except Exception:
            pass
        temp_path.unlink(missing_ok=True)


@app.post('/import-legacy')
def import_legacy_catalog():
    upload = request.files.get('legacy_zip')
    if not upload or not upload.filename:
        flash('Choose a ZIP containing the old Lionel Catalog project or data folder.', 'error')
        return redirect(url_for('settings'))
    if not upload.filename.lower().endswith('.zip'):
        flash('Legacy imports must be uploaded as a .zip file.', 'error')
        return redirect(url_for('settings'))
    try:
        result = import_legacy_zip(upload)
        if result['duplicate']:
            flash(f"That exact archive was already imported ({result['items']} item(s), {result['photos']} photo(s)).", 'error')
        else:
            flash(f"Import complete: {result['items']} item(s) and {result['photos']} photo(s) added to the catalog.", 'success')
    except (zipfile.BadZipFile, sqlite3.DatabaseError, ValueError, OSError) as exc:
        flash(f'Import failed: {exc}', 'error')
    return redirect(url_for('settings'))


@app.get('/settings')
def settings():
    return render_template('settings.html', data_path=str(DATA), migrated_from=str(MIGRATED_FROM) if MIGRATED_FROM else None, api_configured=bool(API_TOKEN))


@app.get('/backup')
def backup_catalog():
    # Create a complete, portable ZIP containing the database, photos, and thumbnails.
    # The archive is created outside DATA so it never includes itself.
    tmp = tempfile.NamedTemporaryFile(prefix='lionel-catalog-', suffix='.zip', delete=False)
    tmp_path = Path(tmp.name)
    tmp.close()
    try:
        with lock, zipfile.ZipFile(tmp_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            if DB.exists():
                zf.write(DB, 'catalog.sqlite3')
            for folder, arc_root in ((PHOTOS, 'photos'), (THUMBS, 'thumbs'), (INTAKE_ORIGINALS, 'intake_originals'), (INTAKE_THUMBS, 'intake_thumbs')):
                if folder.exists():
                    for file in folder.rglob('*'):
                        if file.is_file():
                            zf.write(file, f'{arc_root}/{file.relative_to(folder).as_posix()}')
            zf.writestr('BACKUP_INFO.txt', f'Lionel Train Catalog backup\nData source: {DATA}\n')
        stamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')

        @after_this_request
        def cleanup_backup(response):
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:
                pass
            return response

        return send_file(tmp_path, as_attachment=True, download_name=f'lionel_catalog_backup_{stamp}.zip', mimetype='application/zip')
    except Exception:
        tmp_path.unlink(missing_ok=True)
        raise


@app.errorhandler(413)
def too_large(_):
    if request.path.startswith('/api/'):
        return _api_json_error('Upload too large for the current server limit.', 413)
    return 'Upload too large for the current server limit. For legacy catalog imports, raise the Nginx client_max_body_size setting or use a smaller ZIP.', 413


init_db()
if __name__ == '__main__':
    app.run(host=os.environ.get('HOST', '0.0.0.0'), port=int(os.environ.get('PORT', 5000)), debug=False)
