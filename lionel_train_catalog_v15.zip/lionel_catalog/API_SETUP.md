# Lionel Catalog API setup

The API token must stay on the server and should never be committed to GitHub.

## 1. Generate a token

```bash
openssl rand -hex 32
```

## 2. Store it

```bash
sudo nano /etc/lionel-catalog.env
```

Add:

```text
LIONEL_API_TOKEN=PASTE_THE_GENERATED_TOKEN_HERE
```

Then protect it:

```bash
sudo chmod 600 /etc/lionel-catalog.env
sudo chown root:root /etc/lionel-catalog.env
```

## 3. Tell systemd to load it

Edit:

```bash
sudo nano /etc/systemd/system/lionel-catalog.service
```

Inside `[Service]`, add:

```text
EnvironmentFile=/etc/lionel-catalog.env
```

Then:

```bash
sudo systemctl daemon-reload
sudo systemctl restart lionel-catalog
sudo systemctl status lionel-catalog
```

## 4. Test authentication

Without a token this should return HTTP 401:

```bash
curl -i https://trains.signallosscalculator.com/api/v1/items/1
```

With a valid token:

```bash
curl -i \
  -H "Authorization: Bearer YOUR_TOKEN" \
  https://trains.signallosscalculator.com/api/v1/items/1
```

## Upload individual photos

```bash
curl -X POST https://trains.signallosscalculator.com/api/v1/items \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "name=Lionel 736 Berkshire" \
  -F "description=Postwar locomotive" \
  -F "groups=Locomotives,Postwar,Steam" \
  -F "statuses=Working,Cataloged" \
  -F "photos=@front.jpg" \
  -F "photos=@side.jpg"
```

## Upload a folder as ZIP

Zip the folder first, then:

```bash
curl -X POST https://trains.signallosscalculator.com/api/v1/items \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "name=Lionel 736 Berkshire" \
  -F "groups=Locomotives,Postwar" \
  -F "statuses=Working" \
  -F "archive=@736_Berkshire.zip"
```

## Add photographs to an existing item

```bash
curl -X POST https://trains.signallosscalculator.com/api/v1/items/327/photos \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "photos=@another-angle.jpg"
```
