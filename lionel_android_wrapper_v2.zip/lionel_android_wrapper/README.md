# Lionel Catalog Android Wrapper

A thin Android WebView wrapper for:

`https://trains.signallosscalculator.com`

The app keeps the Lionel Catalog hosted on the server. It adds one native feature the browser/PWA cannot reliably provide: **Bluetooth Volume Up shutter support**.

## What the wrapper does

- Opens directly to `https://trains.signallosscalculator.com/capture`
- Uses the existing hosted Lionel Catalog UI and data
- Grants the hosted site access to the Android camera after normal Android permission approval
- Preserves the site's multi-image gallery picker
- Intercepts `KEYCODE_VOLUME_UP`
- Uses Volume Up as the camera shutter instead of changing phone volume
- Calls `window.takeLionelPhoto()` if the web app exposes it
- Falls back to clicking the existing `#takePhoto` button, so it works with Lionel Catalog V5 as-is
- Keeps external links outside the wrapper
- Refuses cleartext HTTP; the production HTTPS site is required

## Build in Android Studio

1. Install Android Studio on a PC.
2. Choose **Open** and select this project folder (`lionel_android_wrapper`).
3. Let Android Studio install/sync the requested Android SDK and Gradle components.
4. Connect the Android phone with USB debugging enabled, or use an emulator for basic testing.
5. Click **Run**.

For an installable APK:

1. In Android Studio choose **Build > Build App Bundles or APKs > Build APKs**.
2. Android Studio will show the location of the generated APK.
3. Copy/install that APK on the phone.

For long-term distribution, create a signed release APK/AAB with **Build > Generate Signed App Bundle or APK**.

## Using the SmallRig shutter

1. Pair the SmallRig remote with Android normally.
2. Launch Lionel Catalog from this wrapper.
3. Tap **Open camera** and approve camera permission the first time.
4. Press the SmallRig shutter button that Android maps to Volume Up.
5. The wrapper consumes Volume Up and triggers **Take photo** in the catalog.

The volume indicator should no longer appear while the wrapper is in the foreground.

## Optional web-side hook

V5 works through the fallback button click. For a cleaner long-term API, add this inside `initBrowserCamera()` in `static/photos.js`, after `capturePhoto()` is defined:

```javascript
window.takeLionelPhoto = function () {
  if (!stream || snap.disabled) {
    return false;
  }
  capturePhoto();
  return true;
};
```

When this function exists, the Android wrapper uses it instead of locating the button by DOM ID.

## Change the server URL

Edit these constants in:

`app/src/main/java/com/signallosscalculator/lionelcatalog/MainActivity.java`

```java
private static final String CATALOG_HOST = "trains.signallosscalculator.com";
private static final String START_URL = "https://" + CATALOG_HOST + "/capture";
```

## Security

The wrapper only auto-grants WebView video capture to the exact host `trains.signallosscalculator.com`, and Android camera permission still requires user approval. Cleartext HTTP is disabled.
