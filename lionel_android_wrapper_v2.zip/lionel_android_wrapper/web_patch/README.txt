Optional server-side improvement for Lionel Catalog V5.

The Android wrapper already works with V5 by pressing the existing #takePhoto button through JavaScript.
For a stable native/web interface, edit static/photos.js and add this immediately after the capturePhoto() function:

window.takeLionelPhoto = function () {
  if (!stream || snap.disabled) {
    return false;
  }
  capturePhoto();
  return true;
};

Then update the cache-busting version on _camera_form.html from photos.js?v=5 to photos.js?v=6 and restart the Lionel service.
