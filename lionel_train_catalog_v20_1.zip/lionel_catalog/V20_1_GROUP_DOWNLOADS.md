# V20.1 Group Photo ZIP Downloads

V20.1 adds one-click ZIP downloads for grouped photographs.

## Management UI
- Photo Intake: each detected/defined set has a **Download photos** button.
- Logical Groups: each logical train set/group has a **Download ZIP** button.

## API
The existing Bearer token and read scopes are used.

```text
GET /api/v1/intake/sessions/{session_id}/groups/{group_id}/photos.zip
GET /api/v1/logical-groups/{group_id}/photos.zip
```

The intake ZIP includes original uploaded files assigned to that effective group and excludes NEW SET marker photos. Manual grouping overrides are honored. Files are prefixed with their intake sequence number so ordering is preserved.

The logical-group ZIP includes the catalog photographs belonging to all member inventory items. Filenames include the inventory item ID/name and photo number to reduce collisions.

The JSON response for an intake session now includes `photos_zip_url` for every group. `GET /api/v1/logical-groups` also includes `photos_zip_url` for every logical group.
