# Lionel Catalog API setup

The API token must stay on the server and should never be committed to GitHub.

## 1. Generate a token

```bash
openssl rand -hex 32
```

## 2. Store it

```bash
sudo nano /etc/lionel-catalog.env
```

Add:

```text
LIONEL_API_TOKEN=PASTE_THE_GENERATED_TOKEN_HERE
```

Then protect it:

```bash
sudo chmod 600 /etc/lionel-catalog.env
sudo chown root:root /etc/lionel-catalog.env
```

## 3. Tell systemd to load it

Edit:

```bash
sudo nano /etc/systemd/system/lionel-catalog.service
```

Inside `[Service]`, add:

```text
EnvironmentFile=/etc/lionel-catalog.env
```

Then:

```bash
sudo systemctl daemon-reload
sudo systemctl restart lionel-catalog
sudo systemctl status lionel-catalog
```

## 4. Test authentication

Without a token this should return HTTP 401:

```bash
curl -i https://trains.signallosscalculator.com/api/v1/items/1
```

With a valid token:

```bash
curl -i \
  -H "Authorization: Bearer YOUR_TOKEN" \
  https://trains.signallosscalculator.com/api/v1/items/1
```

## Upload individual photos

```bash
curl -X POST https://trains.signallosscalculator.com/api/v1/items \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "name=Lionel 736 Berkshire" \
  -F "description=Postwar locomotive" \
  -F "groups=Locomotives,Postwar,Steam" \
  -F "statuses=Working,Cataloged" \
  -F "photos=@front.jpg" \
  -F "photos=@side.jpg"
```

## Upload a folder as ZIP

Zip the folder first, then:

```bash
curl -X POST https://trains.signallosscalculator.com/api/v1/items \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "name=Lionel 736 Berkshire" \
  -F "groups=Locomotives,Postwar" \
  -F "statuses=Working" \
  -F "archive=@736_Berkshire.zip"
```

## Add photographs to an existing item

```bash
curl -X POST https://trains.signallosscalculator.com/api/v1/items/327/photos \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "photos=@another-angle.jpg"
```

## List and search items

List the newest items:

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://trains.signallosscalculator.com/api/v1/items"
```

Search by text:

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://trains.signallosscalculator.com/api/v1/items?search=Berkshire"
```

Filter by group or status (names are case-insensitive):

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://trains.signallosscalculator.com/api/v1/items?group=Postwar"

curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://trains.signallosscalculator.com/api/v1/items?status=Working"
```

Combine filters:

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://trains.signallosscalculator.com/api/v1/items?group=Locomotives&status=Working"
```

Optional paging parameters are `limit` (1-500, default 100) and `offset`. You can also filter `details=complete` or `details=unfinished`.

## List available groups and statuses

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://trains.signallosscalculator.com/api/v1/groups"

curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://trains.signallosscalculator.com/api/v1/statuses"
```


## Retrieve photographs for visual inspection (V17)

List all photographs for an item. The response includes the stored filename, original filename, photo number, availability flag, and an authenticated download URL for each image:

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://trains.signallosscalculator.com/api/v1/items/13/photos"
```

Download or view one photograph by its catalog photo number:

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://trains.signallosscalculator.com/api/v1/items/13/photos/1" \
  --output item13-photo1.jpg
```

Download every photograph for an item as one ZIP archive:

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://trains.signallosscalculator.com/api/v1/items/13/photos.zip" \
  --output item13-photos.zip
```

All three endpoints are read-only and use the same Bearer token as the rest of the API. Images are not made public. The normal `GET /api/v1/items/<id>` response also includes authenticated photo download URLs plus `photos_url` and `photos_zip_url`.

For item 13, the expected workflow is:

1. `GET /api/v1/items/13` to identify the set and metadata.
2. `GET /api/v1/items/13/photos` to discover all stored photographs.
3. Fetch each `download_url` with the same Bearer token, or use `/api/v1/items/13/photos.zip`.

## V18 intake review endpoints

V18 adds read-only bearer-authenticated access to photo intake sessions. These endpoints are intended for ChatGPT or another review client to inspect staged photographs before any inventory changes are approved.

```text
GET /api/v1/intake/sessions
GET /api/v1/intake/sessions/<id>
GET /api/v1/intake/sessions/<id>/photos/<photo_id>
```

Example:

```bash
curl "https://trains.signallosscalculator.com/api/v1/intake/sessions/1" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

The session response includes original filenames, SHA-256 hashes, capture/import timestamps, marker flags, effective set/group assignments, and authenticated URLs for the original images.

## V19 read/export additions

The read-only ChatGPT credential receives these scopes by default:

- `read:inventory`
- `read:photos`
- `read:intake`
- `read:export`

`GET /api/v1/auth/me` reports the token name, scopes, optional expiration, and configured per-minute rate limit.

Optional JSON token entries may now include an ISO-8601 `expires_at` value. Expired credentials receive HTTP 401. Rotate a token by replacing it in the environment/token file and restarting `lionel-catalog`; never send tokens in URLs or logs.

Default rate limit: `120` requests per minute per worker/client. Override with:

```bash
LIONEL_API_RATE_LIMIT=120
```

Typical errors:

- 400 - invalid request/import format
- 401 - missing, invalid, or expired token
- 403 - token lacks a required scope
- 404 - requested record is missing
- 413 - upload exceeded server/application limits
- 429 - API rate limit exceeded
- 503 - no API credential is configured

Bulk metadata export avoids downloading each image individually:

```text
GET /api/v1/export/inventory.csv
GET /api/v1/export/inventory.json
GET /api/v1/export/intake.csv
GET /api/v1/export/intake.json
GET /api/v1/export/matching/{id}.csv
GET /api/v1/export/matching/{id}.json
GET /api/v1/export/audit.csv
GET /api/v1/export/audit.json
```

API access is written to the management audit log by token **name**, never by token value.

## V20 AI Review Engine

V20 adds a proposal-only AI review layer. AI analysis does not update the master inventory.

Server-side OpenAI analysis requires a server-side API key. Keep it out of GitHub:

```bash
sudo nano /etc/lionel-catalog.env
```

Add:

```text
OPENAI_API_KEY=<your OpenAI API key>
LIONEL_AI_MODEL=gpt-5.5
LIONEL_AI_MAX_IMAGES=10
```

`LIONEL_AI_MODEL` and `LIONEL_AI_MAX_IMAGES` are optional. Restart after changing the environment:

```bash
sudo systemctl daemon-reload
sudo systemctl restart lionel-catalog
```

Open `/ai-review` on the management site. V20 can analyze either a Photo Intake group or an existing catalog item. It produces separate identification, component, and visual-condition proposals. The operational status is always stored as `NOT TESTED` during image-only analysis.

Read-only AI review endpoints:

```text
GET /api/v1/ai/analyses
GET /api/v1/ai/analyses/{analysis_id}
```

These require `read:export` and are available to the normal read-only ChatGPT credential.

V20 also implements proposal submission for a separately scoped integration:

```text
POST /api/v1/ai/proposals
```

That endpoint requires `write:proposals`. It stores a proposal in the same review queue; it does not write to inventory.

For a dedicated proposal-capable client, create a named token in `/etc/lionel-catalog-api-tokens.json` rather than broadening the ordinary read-only ChatGPT token:

```json
{
  "tokens": [
    {
      "name": "ChatGPT Proposal Client",
      "token": "PASTE_A_NEW_RANDOM_TOKEN_HERE",
      "scopes": ["read:inventory", "read:photos", "read:intake", "read:export", "write:proposals"]
    }
  ]
}
```

Do not grant `write:inventory` to the proposal client.
