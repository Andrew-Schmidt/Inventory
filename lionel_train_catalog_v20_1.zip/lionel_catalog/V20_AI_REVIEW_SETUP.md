# V20 AI Review Engine — Setup and Test Guide

## What V20 does

V20 analyzes stored photos and creates reviewable proposals for:

- maker / model / variant / era / gauge
- physical components visible in the photo group
- evidence and uncertainties
- visual condition observations
- a provisional TCA C1-C10 estimate

Image-only analysis always records operational status as **NOT TESTED**. Approval, editing, or rejection on the AI Review page changes only the proposal/review record. It does not change the master inventory.

## 1. Deploy

Add `lionel_train_catalog_v20.zip` to the normal Inventory GitHub repository, then run:

```bash
sudo bash /opt/update.sh
```

## 2. Configure the AI key

Edit the existing server environment file:

```bash
sudo nano /etc/lionel-catalog.env
```

Add the API key without removing the existing catalog API tokens:

```text
OPENAI_API_KEY=YOUR_OPENAI_API_KEY
LIONEL_AI_MODEL=gpt-5.5
LIONEL_AI_MAX_IMAGES=10
```

Restart:

```bash
sudo systemctl daemon-reload
sudo systemctl restart lionel-catalog
sudo systemctl status lionel-catalog
```

The OpenAI API key is a separate API credential and should remain server-side. Do not put it in GitHub or paste it into ordinary ChatGPT conversations.

## 3. First test

Open:

```text
https://trains.signallosscalculator.com/ai-review
```

For a conservative first test, choose a catalog item whose identity you already know, such as the previously discussed Lionel 2343 Santa Fe item, or a well-grouped Photo Intake set.

Press **Analyze item** / **Analyze photos**.

The result is divided into three independently reviewable sections:

1. Identification
2. Physical components
3. Visual condition

Each section can be approved, rejected, reset to pending, or edited. None of these actions modify the master inventory.

## 4. Verify NOT TESTED behavior

The condition section should always show:

```text
Operational status: NOT TESTED
```

This remains true even when the photos look excellent. Mechanical/electrical operation must be recorded separately from actual testing later.

## 5. API review

The read-only ChatGPT token can inspect completed AI proposals:

```bash
curl "https://trains.signallosscalculator.com/api/v1/ai/analyses" \
  -H "Authorization: Bearer YOUR_CHATGPT_TOKEN"
```

Then:

```bash
curl "https://trains.signallosscalculator.com/api/v1/ai/analyses/1" \
  -H "Authorization: Bearer YOUR_CHATGPT_TOKEN"
```

The normal read-only token still cannot submit changes.

## 6. Optional proposal-capable integration

If a future ChatGPT/plugin integration should be able to submit proposals, create a separate token with `write:proposals`. Do **not** add that scope to the general read-only token and do not grant `write:inventory`.

Proposals submitted through `POST /api/v1/ai/proposals` enter the same review queue and still require human review.

## 7. Recommended V20 acceptance test

- Analyze one known catalog item.
- Verify the photos used are the intended item/group.
- Compare the proposed maker/model against the known record.
- Confirm uncertainties are shown instead of guessed values.
- Confirm condition observations are visual-only.
- Confirm operational status says NOT TESTED.
- Edit one proposed field and verify it is logged.
- Approve one section and reject another.
- Confirm the underlying catalog item remains unchanged.
- Verify the read-only API can retrieve the proposal.
- Verify the read-only token still receives 403 on proposal/inventory writes.

Only after those tests pass should V21 add controlled master reconciliation/write-back.
