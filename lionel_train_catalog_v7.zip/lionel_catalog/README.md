# Lionel Train Catalog — V6

A photo-first web catalog for Lionel trains and accessories. It is designed for fast collection work: photograph an item on a phone, save it immediately, then identify and group it later on the phone or a computer.

V6 keeps the permanent-data and PWA architecture and adds faster group handling during photography plus safe deletion of empty groups.

## Normal workflow

1. Open the hosted catalog at `https://trains.signallosscalculator.com`.
2. On Android, use the installed wrapper/PWA or a normal browser.
3. Open **Take photos** and grant camera permission.
4. Select an existing group or type a new group name directly on the capture screen.
5. Photograph one train or piece and save the batch. It becomes an unlabeled entry already assigned to that group.
6. Continue photographing items, then use **Needs details** to add names and notes later.
7. Reopen any entry to add more photographs; its numbering continues automatically.
8. Empty groups can be deleted from **Manage groups** on the catalog page. Groups that still contain items are protected from deletion until those items are moved or ungrouped.

Photo names use the catalog entry ID so duplicate model names do not collide. An unlabeled entry might begin as:

```text
Unlabeled 12_001_ID12.jpg
Unlabeled 12_002_ID12.jpg
```

After the item is named `Lionel 2026 Locomotive`, those same files are renamed to:

```text
Lionel 2026 Locomotive_001_ID12.jpg
Lionel 2026 Locomotive_002_ID12.jpg
```

## Install the catalog as an Android app

The catalog can now be installed from Chrome while using the Tailscale HTTPS address.

1. Start the Windows catalog server.
2. Connect Tailscale on the Android phone.
3. Open the catalog using its `https://...ts.net` address in Chrome.
4. Open **Backup & App**.
5. Tap **Install Lionel Catalog** when the button appears.
6. If Chrome does not show the button, open Chrome's menu and choose **Install app** or **Add to Home screen**.

After installation, the catalog has its own home-screen icon, opens in a standalone app window without the normal browser address bar, and starts directly on the photo-capture page.

The PWA is still a client for the Windows server. The PC server must be running and Tailscale must be connected on the phone. If the server cannot be reached, the installed app shows a simple offline message instead of an old cached catalog page.

### Bluetooth shutter note

The V4 learnable Bluetooth-shutter feature remains available for remotes that send ordinary keyboard events to the browser. The SmallRig remote tested in this project maps its shutter to Android **Volume Up**. Android handles that key before Chrome/PWA JavaScript receives it, so installing the PWA does not by itself enable that physical shutter.

A future thin Android wrapper can intercept `KEYCODE_VOLUME_UP` and forward it to the existing camera JavaScript without changing the Windows server, permanent catalog data, or normal web interface.

## Windows installation

Install Python 3.10 or newer. From the application folder:

```powershell
py -m pip install -r requirements.txt
```

The included Windows launcher is the recommended start method:

```text
Start_Lionel_Catalog.bat
```

It uses this permanent Windows data location:

```text
%USERPROFILE%\LionelCatalogData
```

The launcher currently contains the Tailscale HTTPS hostname configured for this installation. If the PC hostname or tailnet changes, edit `CATALOG_URL` near the top of the batch file.

To start Flask manually:

```powershell
set CATALOG_DATA=%USERPROFILE%\LionelCatalogData
py app.py
```

Then browse locally to `http://localhost:5000`. The live phone camera requires a secure context, so the phone should use the Tailscale `https://...ts.net` URL rather than an HTTP LAN or numeric Tailscale IP address.

## Permanent data and seamless upgrades

The application code and collection data are intentionally separated. On Windows the collection lives in:

```text
%USERPROFILE%\LionelCatalogData
```

It contains:

```text
catalog.sqlite3
photos\
thumbs\
```

When installing V5 over V4, **do not move or replace this folder**. Extract the new application somewhere convenient and run its launcher. It points to the same permanent data directory, so the existing database and photographs appear automatically.

### Importing an older V1–V3 catalog

If the permanent folder does not yet contain `catalog.sqlite3`, the app checks standard old-version locations and copies an existing catalog into the permanent folder. The old data is not deleted.

For a V3 installation in a nonstandard location, edit and run:

```text
Import_V3_Data.bat
```

before first launch. The script refuses to overwrite an existing permanent database.

## Backup

Open **Backup & App** and select **Download complete backup**. The generated ZIP includes:

- `catalog.sqlite3`
- all catalog photographs
- generated thumbnails

Keep occasional backups on another drive or computer. The permanent data folder makes upgrades safe and easy, but it does not protect against disk failure or accidental deletion.

## Camera and image handling

The in-browser camera uses `getUserMedia`, which requires HTTPS on a phone. Captured frames are sent to the server as JPEG images. Uploaded images are auto-rotated using EXIF information, converted to JPEG, and reduced to a maximum dimension of 3200 pixels. Thumbnails are generated for fast catalog browsing.

The original pixel-perfect upload is not retained after normalization. Keep original photos separately if that matters for archival purposes.

The batch upload limit is 120 MB.

## PWA files added in V5

V5 adds:

```text
static/manifest.webmanifest
static/sw.js
static/pwa.js
static/offline.html
static/icons/
```

The service worker intentionally does **not** cache database-generated catalog pages or train photographs for offline use. It caches only the app shell/static assets and an offline notice. This avoids displaying stale collection data when the Windows server is unavailable.


## V6 server deployment

The Android wrapper still opens `/capture` and the physical Volume Up shutter continues to target the existing `#takePhoto` button, so no Android rebuild is required for V6. Deploy the updated web files, install requirements if needed, and restart the Gunicorn systemd service.


## V7 multi-group support

V7 changes groups into many-to-many tags. Each catalog item can belong to any number of groups. Existing V6 single-group assignments are migrated automatically the first time V7 starts; no manual database conversion is required. Group filtering matches items that contain the selected group, and a group can only be deleted when it is no longer assigned to any items.
