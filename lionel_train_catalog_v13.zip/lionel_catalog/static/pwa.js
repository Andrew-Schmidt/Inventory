(() => {
  const nativeWrapper = /LionelCatalogAndroid/i.test(navigator.userAgent);

  function refreshNativeUi() {
    if (!nativeWrapper) return;
    document.documentElement.classList.add('native-wrapper');
    document.querySelectorAll('.install-nav,[data-pwa-install-panel]').forEach((node) => {
      node.hidden = true;
    });
  }

  if ('serviceWorker' in navigator && window.isSecureContext) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch((error) => {
        console.warn('Service worker registration failed:', error);
      });
    });
  }

  window.addEventListener('DOMContentLoaded', refreshNativeUi);
})();
