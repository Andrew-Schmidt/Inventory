/* Shared photo-first camera for new entries and existing trains. */
function initBrowserCamera({ formId, inputId, videoId, startId, snapId, switchId,
                             countId, previewsId, saveId, statusId, fallbackId,
                             learnRemoteId, clearRemoteId, remoteStatusId }) {
  const byId = (id) => document.getElementById(id);
  const form = byId(formId), input = byId(inputId), video = byId(videoId);
  const start = byId(startId), snap = byId(snapId), flip = byId(switchId);
  const count = byId(countId), previews = byId(previewsId), save = byId(saveId);
  const status = byId(statusId), fallback = byId(fallbackId);
  const learnRemote = byId(learnRemoteId), clearRemote = byId(clearRemoteId);
  const remoteStatus = byId(remoteStatusId);

  let stream = null, facing = 'environment', photos = [], urls = [];
  let learningRemote = false;
  const REMOTE_KEY = 'lionelCatalogRemoteShutterV1';

  function render() {
    urls.forEach((url) => URL.revokeObjectURL(url)); urls = [];
    previews.replaceChildren();
    photos.forEach((file, index) => {
      const tile = document.createElement('div'); tile.className = 'preview-tile';
      const img = document.createElement('img');
      const url = URL.createObjectURL(file); urls.push(url);
      img.src = url; img.alt = `Photo ${index + 1}`;
      const remove = document.createElement('button'); remove.type = 'button';
      remove.className = 'remove-photo'; remove.textContent = '×';
      remove.setAttribute('aria-label', `Remove photo ${index + 1}`);
      remove.addEventListener('click', () => { photos.splice(index, 1); render(); });
      const label = document.createElement('span'); label.textContent = `#${index + 1}`;
      tile.append(img, remove, label); previews.append(tile);
    });
    count.textContent = photos.length ? `${photos.length} photo${photos.length === 1 ? '' : 's'} ready to save` : 'No photos yet. Take pictures of one train or piece.';
    save.disabled = photos.length === 0;
  }

  function stopCamera() {
    if (stream) stream.getTracks().forEach((track) => track.stop());
    stream = null; video.srcObject = null; video.hidden = true;
    snap.disabled = true; flip.disabled = true;
    start.textContent = 'Open camera';
  }

  async function openCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      status.textContent = 'In-browser camera requires HTTPS (or localhost on this device). Use gallery upload below if HTTPS is not set up.';
      fallback.hidden = false; return;
    }
    stopCamera();
    status.textContent = 'Requesting camera permission…';
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { facingMode: { ideal: facing }, width: { ideal: 1920 }, height: { ideal: 1080 } }
      });
      video.srcObject = stream; video.hidden = false;
      await video.play();
      start.textContent = 'Restart camera'; snap.disabled = false; flip.disabled = false;
      status.textContent = 'Camera ready. Tap Take photo or use your learned Bluetooth shutter.';
    } catch (error) {
      stopCamera(); fallback.hidden = false;
      status.textContent = error.name === 'NotAllowedError'
        ? 'Camera permission was denied. Allow camera access in browser settings, or choose images below.'
        : 'Could not open the camera. Check HTTPS and camera permissions, or choose images below.';
    }
  }

  function capturePhoto() {
    if (!stream || !video.videoWidth || !video.videoHeight || snap.disabled) return;
    const canvas = document.createElement('canvas');
    const factor = Math.min(1, 2400 / Math.max(video.videoWidth, video.videoHeight));
    canvas.width = Math.round(video.videoWidth * factor);
    canvas.height = Math.round(video.videoHeight * factor);
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    snap.disabled = true;
    canvas.toBlob((blob) => {
      if (blob) {
        photos.push(new File([blob], `camera-${Date.now()}-${photos.length + 1}.jpg`, { type: 'image/jpeg' }));
        render(); status.textContent = 'Photo captured. Take another, or save this entry.';
      } else {
        status.textContent = 'Could not capture photo. Please try again.';
      }
      snap.disabled = !stream;
    }, 'image/jpeg', 0.9);
  }

  function remoteFingerprint(event) {
    return {
      key: event.key || '',
      code: event.code || '',
      keyCode: Number(event.keyCode || event.which || 0)
    };
  }

  function fingerprintLabel(fp) {
    if (!fp) return 'Not configured';
    if (fp.code) return fp.code;
    if (fp.key && fp.key !== 'Unidentified') return fp.key === ' ' ? 'Space' : fp.key;
    return fp.keyCode ? `Key ${fp.keyCode}` : 'Unknown key';
  }

  function loadRemote() {
    try {
      const raw = localStorage.getItem(REMOTE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (_) {
      return null;
    }
  }

  function saveRemote(fp) {
    localStorage.setItem(REMOTE_KEY, JSON.stringify(fp));
  }

  function remoteMatches(event, saved) {
    if (!saved) return false;
    const current = remoteFingerprint(event);
    if (saved.code && current.code && saved.code === current.code) return true;
    if (saved.key && current.key && saved.key === current.key && saved.key !== 'Unidentified') return true;
    return !!(saved.keyCode && current.keyCode && saved.keyCode === current.keyCode);
  }

  function refreshRemoteStatus(message) {
    if (!remoteStatus) return;
    const saved = loadRemote();
    remoteStatus.textContent = message || (saved
      ? `Ready — learned button: ${fingerprintLabel(saved)}. Open the camera, then press the remote to take a photo.`
      : 'Pair the remote with the phone, then tap Learn remote button and press its shutter once.');
  }

  function isTypingTarget(target) {
    if (!target) return false;
    const tag = (target.tagName || '').toLowerCase();
    return ['input', 'textarea', 'select'].includes(tag) || target.isContentEditable;
  }

  start.addEventListener('click', openCamera);
  flip.addEventListener('click', () => { facing = facing === 'environment' ? 'user' : 'environment'; openCamera(); });
  snap.addEventListener('click', capturePhoto);

  if (learnRemote) {
    learnRemote.addEventListener('click', () => {
      learningRemote = true;
      learnRemote.textContent = 'Waiting for remote…';
      refreshRemoteStatus('Press the Bluetooth shutter button once now.');
      // Remove focus from the learn button so an Enter-style remote does not simply click it again.
      learnRemote.blur();
    });
  }

  if (clearRemote) {
    clearRemote.addEventListener('click', () => {
      learningRemote = false;
      localStorage.removeItem(REMOTE_KEY);
      if (learnRemote) learnRemote.textContent = 'Learn remote button';
      refreshRemoteStatus('Remote mapping cleared. Tap Learn remote button to set it again.');
    });
  }

  document.addEventListener('keydown', (event) => {
    if (event.repeat) return;

    if (learningRemote) {
      event.preventDefault();
      event.stopPropagation();
      const fp = remoteFingerprint(event);
      saveRemote(fp);
      learningRemote = false;
      if (learnRemote) learnRemote.textContent = 'Learn remote button';
      refreshRemoteStatus(`Learned ${fingerprintLabel(fp)}. Open the camera and press the remote again to test it.`);
      return;
    }

    const saved = loadRemote();
    if (!saved || !remoteMatches(event, saved) || isTypingTarget(event.target)) return;
    event.preventDefault();
    event.stopPropagation();
    if (!stream) {
      refreshRemoteStatus('Remote detected. Open the camera first, then the shutter button will take photos.');
      return;
    }
    capturePhoto();
  }, true);

  input.addEventListener('change', () => {
    const incoming = [...input.files].filter((file) => file.type.startsWith('image/') || /\.(heic|heif)$/i.test(file.name));
    photos.push(...incoming); render();
    input.value = '';
    if (incoming.length) status.textContent = `Added ${incoming.length} photo(s) from your device.`;
  });

  form.addEventListener('submit', (event) => {
    if (!photos.length) {
      event.preventDefault(); status.textContent = 'Take or choose at least one photo.'; return;
    }
    const transfer = new DataTransfer();
    photos.forEach((file) => transfer.items.add(file));
    input.files = transfer.files;
    save.disabled = true; save.textContent = 'Saving photos…';
    status.textContent = 'Uploading your pictures. Keep this page open.';
    stopCamera();
  });

  window.addEventListener('pagehide', stopCamera);
  if (!window.isSecureContext) {
    status.textContent = 'Camera preview requires HTTPS on a phone. Photo upload still works over your local network.';
    fallback.hidden = false;
  }
  refreshRemoteStatus();
  render();
}
