(() => {
  let installPrompt = null;
  const buttons = () => [...document.querySelectorAll('[data-install-pwa]')];
  const statusNodes = () => [...document.querySelectorAll('[data-pwa-status]')];

  function standalone() {
    return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  }

  function setStatus(message) {
    statusNodes().forEach((node) => { node.textContent = message; });
  }

  function refreshButtons() {
    buttons().forEach((button) => {
      if (standalone()) {
        button.hidden = true;
      } else {
        button.hidden = !installPrompt;
      }
    });
    if (standalone()) setStatus('Installed app mode is active.');
  }

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    installPrompt = event;
    refreshButtons();
    setStatus('This device is ready to install the Lionel Catalog.');
  });

  document.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-install-pwa]');
    if (!button || !installPrompt) return;
    button.disabled = true;
    try {
      await installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      setStatus(choice.outcome === 'accepted'
        ? 'Install accepted. Look for Lionel Catalog on the home screen.'
        : 'Install canceled. You can install it later from Chrome.');
    } finally {
      installPrompt = null;
      button.disabled = false;
      refreshButtons();
    }
  });

  window.addEventListener('appinstalled', () => {
    installPrompt = null;
    refreshButtons();
    setStatus('Lionel Catalog installed successfully.');
  });

  if ('serviceWorker' in navigator && window.isSecureContext) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch((error) => {
        console.warn('Service worker registration failed:', error);
      });
    });
  }

  window.addEventListener('DOMContentLoaded', refreshButtons);
})();
