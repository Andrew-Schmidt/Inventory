@echo off
setlocal EnableExtensions
TITLE Lionel Catalog V3 Data Import

set "SOURCE=%USERPROFILE%\Downloads\lionel_train_catalog_v3\lionel_catalog\data"
set "DEST=%USERPROFILE%\LionelCatalogData"

echo Lionel Train Catalog - V3 Import
echo.
echo Source: %SOURCE%
echo Destination: %DEST%
echo.

if not exist "%SOURCE%\catalog.sqlite3" (
    echo ERROR: No V3 catalog database was found at the standard location.
    echo If V3 was moved, edit SOURCE near the top of this file.
    pause
    exit /b 1
)

if exist "%DEST%\catalog.sqlite3" (
    echo A V4 catalog already exists in the destination.
    echo Nothing was changed. This protects your current collection from being overwritten.
    pause
    exit /b 1
)

mkdir "%DEST%" >nul 2>&1
powershell -NoProfile -Command "Copy-Item -LiteralPath '%SOURCE%\*' -Destination '%DEST%' -Recurse -Force"
if errorlevel 1 (
    echo Import failed.
    pause
    exit /b 1
)

echo.
echo Import complete. The V3 data was COPIED; the original was not deleted.
pause
