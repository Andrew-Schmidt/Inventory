@echo off
setlocal EnableExtensions
TITLE Lionel Train Catalog Launcher

REM V5 stores the catalog in a permanent folder that survives app upgrades.
set "APP_DIR=%~dp0"
set "CATALOG_DATA=%USERPROFILE%\LionelCatalogData"
set "CATALOG_URL=https://desktop-p02vbmm.tail8730b1.ts.net/"

REM Locate Tailscale.
set "TS=tailscale.exe"
where tailscale.exe >nul 2>&1
if errorlevel 1 (
    if exist "%ProgramFiles%\Tailscale\tailscale.exe" (
        set "TS=%ProgramFiles%\Tailscale\tailscale.exe"
    ) else (
        echo ERROR: Tailscale was not found.
        pause
        exit /b 1
    )
)

if not exist "%APP_DIR%app.py" (
    echo ERROR: app.py was not found beside this launcher.
    pause
    exit /b 1
)

echo Connecting Tailscale...
"%TS%" up
if errorlevel 1 (
    echo Could not connect Tailscale.
    pause
    exit /b 1
)

REM V5 reuses the permanent catalog folder and can automatically copy a V3 catalog from the standard Downloads location
REM into %%USERPROFILE%%\LionelCatalogData on its first start, if needed.
echo Catalog data: %CATALOG_DATA%

powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:5000/' -TimeoutSec 2 | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1
if errorlevel 1 (
    echo Starting Lionel Catalog...
    start "Lionel Catalog Server" /D "%APP_DIR%" cmd /k "set CATALOG_DATA=%CATALOG_DATA%&& py app.py"
) else (
    echo Lionel Catalog is already running.
)

echo Waiting for server...
for /l %%i in (1,1,20) do (
    powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:5000/' -TimeoutSec 2 | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1
    if not errorlevel 1 goto server_ready
    timeout /t 2 /nobreak >nul
)

echo ERROR: Catalog did not start. Check the server window.
pause
exit /b 1

:server_ready
echo Enabling Tailscale HTTPS...
"%TS%" serve --bg 5000
if errorlevel 1 (
    echo Tailscale Serve did not start.
    pause
    exit /b 1
)

echo Opening catalog...
start "" "%CATALOG_URL%"
echo.
echo Lionel Catalog is ready.
echo Data is stored permanently at: %CATALOG_DATA%
echo Keep the Lionel Catalog Server window open.
pause
